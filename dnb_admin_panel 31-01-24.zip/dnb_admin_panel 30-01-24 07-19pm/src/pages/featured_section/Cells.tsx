import React from "react";
import {
  Popover,
  Whisper,
  Checkbox,
  Dropdown,
  IconButton,
  Table,
  CellProps,
  Toggle,
} from "rsuite";
import MoreIcon from "@rsuite/icons/legacy/More";
import { image_url } from "@/lib/api";

const { Cell } = Table;

export const NameCell = ({ rowData, dataKey, ...props }: CellProps) => {
  const speaker = (
    <Popover title="Description">
      <p>
        <b>Name:</b> {rowData.name}
      </p>
      <p>
        <b>Gender:</b> {rowData.gender}
      </p>
      <p>
        <b>Email:</b> {rowData.email}
      </p>
      <p>
        <b>Profile Name:</b> {rowData.profileName}
      </p>
    </Popover>
  );

  return (
    <Cell {...props}>
      <Whisper placement="top" speaker={speaker}>
        <a>{dataKey ? rowData[dataKey] : null}</a>
      </Whisper>
    </Cell>
  );
};

export const ImageCell = ({ rowData, dataKey, ...props }: CellProps) => (
  <Cell {...props} style={{ padding: 0 }}>
    <div
      style={{
        width: 40,
        height: 40,
        background: "#f5f5f5",
        borderRadius: 6,
        marginTop: 2,
        overflow: "hidden",
        display: "inline-block",
      }}
    >
      <img src={`${image_url}${rowData[dataKey]}`} width="40" />
    </div>
  </Cell>
);

export const CheckCell = ({
  rowData,
  onChange,
  checkedKeys,
  dataKey,
  ...props
}: CellProps & {
  checkedKeys: number[];
  onChange: (value: any, checked: boolean) => void;
}) => (
  <Cell {...props} style={{ padding: 0 }}>
    <div style={{ lineHeight: "46px" }}>
      <Checkbox
        value={rowData[dataKey!]}
        inline
        onChange={onChange}
        checked={checkedKeys.some((item) => item === rowData[dataKey!])}
      />
    </div>
  </Cell>
);

export const ActionCell = (props) => {
  const { rowData, editData, editOpen, setEditData, setEditOpen, deleteOpen, setDeleteOpen } = {
    ...props,
  };
  const handleSelect = (eventKey, onClose) => {
    console.log(eventKey)
    if (eventKey == 1) {
      setEditOpen(true);
      setEditData({ ...rowData });
    }

    if (eventKey == 2) {
      setEditData({ ...rowData });

      setDeleteOpen(true);
    }

    onClose();
  };
  const renderMenu = ({ onClose, left, top, className }: any, ref) => {
    return (
      <Popover ref={ref} className={className} style={{ left, top }} full>
        <Dropdown.Menu onSelect={(eventKey) => handleSelect(eventKey, onClose)}>
          {/* <Dropdown.Item eventKey={1}>Edit</Dropdown.Item> */}
          <Dropdown.Item eventKey={2}>Delete</Dropdown.Item>
        </Dropdown.Menu>
      </Popover>
    );
  };

  return (
    <Cell {...props} className="link-group">
      <Whisper placement="autoVerticalEnd" trigger="click" speaker={renderMenu}>
        <IconButton appearance="subtle" icon={<MoreIcon />} />
      </Whisper>
    </Cell>
  );
};


export const StatusToggleCell = (props) => {
  const { rowData, dataKey, statusToggle } = {
    ...props,
  };



  return (
    <Cell {...props} className="link-group">

      <Toggle
        checkedChildren="Active"
        unCheckedChildren="Inactive"
        checked={rowData[dataKey]}
        onChange={() => {
          statusToggle({
            id: rowData?._id,
            status: rowData[dataKey] ? false : true
          })
        }}
      />

    </Cell>

  );
};

