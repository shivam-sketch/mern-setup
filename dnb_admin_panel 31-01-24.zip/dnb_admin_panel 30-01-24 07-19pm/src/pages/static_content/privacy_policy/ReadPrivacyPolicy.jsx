import api from '@/lib/api';
import { useQuery } from '@tanstack/react-query';
import React from 'react'

const ReadPrivacyPolicy = () => {

    const { data: privacy_policy, refetch } = useQuery({
        queryKey: ["get-privacy-policy"],
        queryFn: () => api.get(`web/privacy-policy`),
        select: (res) => res?.data?.data,
    });
    return (
        <div dangerouslySetInnerHTML={{ __html: privacy_policy?.privacy_policy }}>






        </div>
    )
}

export default ReadPrivacyPolicy