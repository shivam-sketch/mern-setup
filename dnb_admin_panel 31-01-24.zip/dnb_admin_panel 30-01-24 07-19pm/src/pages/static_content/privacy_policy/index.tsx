import React from 'react';
import { Breadcrumb, Panel } from 'rsuite';
import PrivacyPolicy from './PrivacyPolicy';

const Page = () => {
  return (
    <Panel
      header={
        <>
          <h3 className="title">Static</h3>
          <Breadcrumb>
            <Breadcrumb.Item href="/">Static</Breadcrumb.Item>
            <Breadcrumb.Item active>Privacy Policy</Breadcrumb.Item>
          </Breadcrumb>
        </>
      }
    >
      <PrivacyPolicy />
    </Panel>
  );
};

export default Page;
