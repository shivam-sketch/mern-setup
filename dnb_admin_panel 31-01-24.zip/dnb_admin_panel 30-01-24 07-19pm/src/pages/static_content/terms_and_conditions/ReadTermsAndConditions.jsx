import api from '@/lib/api';
import { useQuery } from '@tanstack/react-query';
import React from 'react'

const ReadTermsAndConditions = () => {

    const { data: terms_and_condition, refetch } = useQuery({
        queryKey: ["get-terms-and-conditions"],
        queryFn: () => api.get(`web/terms-and-conditions`),
        select: (res) => res?.data?.data,
    });
    return (
        <div dangerouslySetInnerHTML={{ __html: terms_and_condition?.terms_and_condition }}>






        </div>
    )
}

export default ReadTermsAndConditions