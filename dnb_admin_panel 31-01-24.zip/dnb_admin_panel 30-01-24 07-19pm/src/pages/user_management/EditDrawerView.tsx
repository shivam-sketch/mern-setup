import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import api from "@/lib/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker,
} from "rsuite";

const EditDrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const [code, setCode] = useState("");
  const [phone, setPhone] = useState("");
  const [flag, setFlag] = useState("");
  const { onClose, editData, setEditData, setEditOpen, ...rest } = props;

  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/edit-users", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        cogoToast.success("user Edited");
        onClose();
      }
    },
  });

  const { data: artists, refetch } = useQuery({
    queryKey: ["get-artists"],
    queryFn: () => axiosPrivate.get(`web/get-artists`),
    select: (res) => res.data.data,
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    defaultValues: {},
  });
  console.log(editData)
  useEffect(() => {
    setValue("name", editData.name);
    setValue("profileName", editData.profileName);
    setValue("bio", editData.bio);
    setValue("email", editData.email);
    setValue("country", editData.country);
    setValue("interestedArtists", editData.interestedArtists);
    setValue("gender", editData.gender);
    setValue("city", editData.city);
    setPhone(`${editData?.dialCode?.slice(1)}${editData?.phone}`);
    setCode(editData?.dialCode?.slice(1));

  }, [editData]);






  const onSubmit = (data) => {
    if (!phone) {
      cogoToast.error("Mobile number is not entered");
      return;
    }
    let dialCode = code;
    let withoutCodeNumber = phone.slice(code.length);
    let body = {
      ...data,
      phone: withoutCodeNumber,
      dialCode: `+${dialCode}`,
      email: data.email == editData.email ? null : data.email,
      userId: editData._id
    };

    mutate(body);
  };
  console.log(rest);
  return (
    <Drawer
      backdrop="static"
      size="sm"
      placement="right"
      onClose={onClose}
      {...rest}
    >
      <Drawer.Header>
        <Drawer.Title>Edit</Drawer.Title>
        <Drawer.Actions>

          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)}>
          <Stack justifyContent="space-between" style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 15 }}>
            <Form.Group>
              <Form.ControlLabel>Name</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: "this field is required",
                }}
                render={({ field }) => (
                  <Form.Control name="name" {...field} />
                )}
                name="name"
              />

              {errors.name && (
                <p style={{ color: "red" }} role="alert">
                  {errors.name.message}
                </p>
              )}
            </Form.Group>
            <Form.Group>
              <Form.ControlLabel>Profile Name</Form.ControlLabel>
              <Controller
                control={control}
                rules={{
                  required: "this field is required",
                }}
                render={({ field }) => (
                  <Form.Control
                    name="profileName"
                    {...field}

                  />
                )}
                name="profileName"
              />

              {errors?.profileName && (
                <p style={{ color: "red" }} role="alert">
                  {errors?.profileName.message}
                </p>
              )}
            </Form.Group>
          </Stack>

          <Form.Group>
            <Form.ControlLabel>Bio</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => (
                <Form.Control name="bio" {...field} type="text" />
              )}
              name="bio"
            />

            {errors.bio && (
              <p style={{ color: "red" }} role="alert">
                {errors.bio.message}
              </p>
            )}
          </Form.Group>

          <Form.Group>
            <Form.ControlLabel>Email</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => (
                <Form.Control name="email" {...field} type="email" />
              )}
              name="email"
            />
            {errors.email && (
              <p style={{ color: "red" }} role="alert">
                {errors.email.message}
              </p>
            )}
          </Form.Group>

          <Form.Group>
            <Form.ControlLabel>Phone Number</Form.ControlLabel>

            {/* <Controller
              control={control}
              rules={{
                required: 'this field is required'
              }}
              render={({ field }) => (
                <Form.Control name="phone" {...field} type="number" />

              )}
              name="phone"
            /> */}

            <PhoneInput
              country={"in"}
              value={phone}
              containerClass="rs-theme-dark"
              onChange={(value, country) => {
                console.log(country)
                setCode(country.dialCode);

                setPhone(value);
                setFlag(country.name);
              }}
              enableSearch={true}
            />

            {errors.phone && (
              <p style={{ color: "red" }} role="alert">
                {errors.phone.message}
              </p>
            )}
          </Form.Group>

          <Form.Group>
            <Form.ControlLabel>Country</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => (
                <Form.Control name="country" {...field} type="text" />
              )}
              name="country"
            />

            {errors.country && (
              <p style={{ color: "red" }} role="alert">
                {errors.country.message}
              </p>
            )}
          </Form.Group>

          <Form.Group>
            <Form.ControlLabel>City</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => (
                <Form.Control name="city" {...field} type="text" />
              )}
              name="city"
            />

            {errors.city && (
              <p style={{ color: "red" }} role="alert">
                {errors.city.message}
              </p>
            )}
          </Form.Group>

          <Stack direction="row" spacing={12} alignItems="flex-start" style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 15 }}>
            <Stack spacing={6} style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 15 }}>
              <Form.Group>
                <Form.ControlLabel>Gender</Form.ControlLabel>

                <Controller
                  control={control}
                  rules={
                    {
                      // required: 'this field is required'
                    }
                  }
                  render={({ field }) => (
                    <Form.Control
                      name="selectPicker"
                      {...field}
                      accepter={SelectPicker}
                      data={["Male", "Female", "Others"].map((item) => ({
                        label: item,
                        value: item,
                      }))}
                    />
                  )}
                  name="gender"
                />
                {errors.gender && (
                  <p style={{ color: "red" }} role="alert">
                    {errors.gender.message}
                  </p>
                )}
              </Form.Group>
            </Stack>
            <Stack spacing={6} style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 15 }}>

              <Form.Group>
                <Form.ControlLabel>interestedArtists</Form.ControlLabel>

                <Controller
                  control={control}
                  rules={
                    {
                      // required: 'this field is required'
                    }
                  }
                  render={({ field }) => (
                    <CheckPicker
                      data={artists?.map((item) => {
                        return {
                          label: item.name,
                          value: item._id,
                        };
                      })}
                      style={{ width: 224 }}
                      {...field}
                    />
                  )}
                  name="interestedArtists"
                />

                {errors.interestedArtists && (
                  <p style={{ color: "red" }} role="alert">
                    {errors.interestedArtists.message}
                  </p>
                )}
              </Form.Group>
            </Stack>

          </Stack>

          <Button type="submit" appearance="primary">
            Submit
          </Button>
        </Form>
      </Drawer.Body>
    </Drawer>
  );
};

export default EditDrawerView;
