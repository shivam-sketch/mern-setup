import ImageUploader from "@/components/ImageUploader";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import { useCommon } from "@/hooks/useCommon";
import api from "@/lib/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import axios from "axios";
import cogoToast from "cogo-toast";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import Dropzone from "react-dropzone";
import { Controller, useForm } from "react-hook-form";
import { FaClock } from "react-icons/fa";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker,
  DatePicker,
  Grid,
  Row,
  Col,
} from "rsuite";

const DrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const {
    images,
    setImages,
    imagesUrl,
    setImagesUrl,
    isUploaded,
    setIsUploaded,
  } = useCommon();

  const { onClose, ...rest } = props;

  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    defaultValues: {},
  });

  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/add-artists", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 201) {
        cogoToast.success("Artist Added");
        setImagesUrl([]);

        reset();
        onClose();
      }
    },
  });

  const onSubmit = (data) => {
    if (imagesUrl?.length == 0) {
      cogoToast.error("Images Not Uploaded");
    } else {
      let body = {
        ...data,
        image: imagesUrl[0],
      };

      mutate(body);
    }
  };

  
  return (
    <Drawer
      backdrop="static"
      size="sm"
      placement="right"
      onClose={onClose}
      {...rest}
    >
      <Drawer.Header>
        <Drawer.Title>Add a new Artists</Drawer.Title>
        <Drawer.Actions>
          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)}>
          <Form.Group>
            <Form.ControlLabel>Artist Name</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => <Form.Control name="name" {...field} />}
              name="name"
            />

            {errors.name && (
              <p style={{ color: "red" }} role="alert">
                {errors.name.message}
              </p>
            )}
          </Form.Group>

          <ImageUploader limit={1} />

          <div className="row" style={{ marginTop: 10 }}>
            <Button type="submit" appearance="primary" disabled={!isUploaded}>
              Submit
            </Button>
          </div>
        </Form>
      </Drawer.Body>
    </Drawer>
  );
};

export default DrawerView;
