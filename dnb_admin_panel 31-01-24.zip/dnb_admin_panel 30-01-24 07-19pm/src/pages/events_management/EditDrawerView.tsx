import ImageUploader from "@/components/ImageUploader";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import { useCommon } from "@/hooks/useCommon";
import api from "@/lib/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import Dropzone from "react-dropzone";
import { Controller, useForm } from "react-hook-form";
import { FaClock } from "react-icons/fa";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker,
  DatePicker,
} from "rsuite";

const EditDrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const { onClose, editData, setEditData, setEditOpen, ...rest } = props;
  const {
    images,
    setImages,
    imagesUrl,
    setImagesUrl,
    isUploaded,
    setIsUploaded,
  } = useCommon();

  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/edit-events", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        cogoToast.success("Event Edited");
        setImagesUrl([]);

        onClose();
      }
    },
  });

  const { data: artists, refetch } = useQuery({
    queryKey: ["get-artists"],
    queryFn: () => axiosPrivate.get(`web/get-artists`),
    select: (res) => res.data.data,
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm({
    defaultValues: {
      // startDate: new Date(editData?.isoStartDate)
    },
  });

  const startTime = watch("startTime");
  const startDate = watch("startDate");
  console.log("startDate", startDate);

  useEffect(() => {
    if (editData) {
      setValue("eventName", editData.eventName);
      setValue("bookUrl", editData.bookUrl);

      // setValue("startDate", new Date(editData.startDate));
      // setValue("startTime", new Date(editData.isoStartTime));
      // setValue("endTime", new Date(editData?.isoEndTime));
      setValue("location", editData.location);
      setValue("description", editData.description);
      setValue("featuredArtists", editData.featuredArtists);
    }
  }, [editData]);

  const onSubmit = (data) => {
    let body = {
      ...data,
      id: editData?._id,
      startDate: dayjs(editData?.isoStartDate).toISOString(),
      endDate: dayjs(editData?.isoEndDate).toISOString(),
      startTime: dayjs(editData?.isoStartTime).toISOString(),
      endTime: dayjs(editData?.isoEndTime).toISOString(),
      hostedBy: "DNB All Stars",
    };

    if (data.startDate) {
      body["startDate"] = data.startDate;
    }
    if (data.endDate) {
      body["endDate"] = data.endDate;
    }
    if (data.startTime) {
      body["startTime"] = data.startTime;
    }
    if (data.endTime) {
      body["endTime"] = data.endTime;
    }
    if (imagesUrl?.length > 0) {
      body["image"] = [...editData?.image, ...imagesUrl];
    }

    mutate(body);
  };

  console.log(images);
  console.log(editData);

  return (
    <Drawer
      backdrop="static"
      size="sm"
      placement="right"
      onClose={onClose}
      {...rest}
    >
      <Drawer.Header>
        <Drawer.Title>Edit a new Event</Drawer.Title>
        <Drawer.Actions>
          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)}>
          <Stack
            justifyContent="space-between"
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 7,
            }}
          >
            <Form.Group>
              <Form.ControlLabel>Event Name</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: "this field is required",
                }}
                render={({ field }) => (
                  <Form.Control name="eventName" {...field} />
                )}
                name="eventName"
              />

              {errors.eventName && (
                <p style={{ color: "red" }} role="alert">
                  {errors.eventName.message}
                </p>
              )}
            </Form.Group>

            <Form.Group>
              <Form.ControlLabel>Book Url</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: "this field is required",
                }}
                render={({ field }) => (
                  <Form.Control name="bookUrl" {...field} />
                )}
                name="bookUrl"
              />

              {errors.bookUrl && (
                <p style={{ color: "red" }} role="alert">
                  {errors.bookUrl.message}
                </p>
              )}
            </Form.Group>
          </Stack>

          <Stack
            spacing={12}
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 2,
            }}
          >
            <Form.Group>
              <Form.ControlLabel>Start Date</Form.ControlLabel>
              <Controller
                control={control}
                rules={
                  {
                    // required: 'this field is required'
                  }
                }
                render={({ field }) => (
                  <Form.Control
                    name="datePicker"
                    defaultValue={new Date(editData?.isoStartDate)}
                    accepter={DatePicker}
                    {...field}
                  />
                )}
                name="startDate"
              />

              {errors?.startDate && (
                <p style={{ color: "red" }} role="alert">
                  {errors?.startDate.message}
                </p>
              )}
            </Form.Group>

            <Form.Group>
              <Form.ControlLabel>End Date</Form.ControlLabel>
              <Controller
                control={control}
                rules={
                  {
                    // required: 'this field is required'
                  }
                }
                render={({ field }) => (
                  <Form.Control
                    name="datePicker"
                    defaultValue={new Date(editData?.isoEndDate)}
                    accepter={DatePicker}
                    {...field}
                  />
                )}
                name="endDate"
              />

              {errors?.endDate && (
                <p style={{ color: "red" }} role="alert">
                  {errors?.endDate.message}
                </p>
              )}
            </Form.Group>
          </Stack>
          <Stack
            spacing={12}
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 2,
            }}
          >
            <Form.Group>
              <Form.ControlLabel>Start Time</Form.ControlLabel>
              <Controller
                control={control}
                rules={
                  {
                    // required: 'this field is required'
                  }
                }
                render={({ field }) => (
                  <DatePicker
                    format="HH:mm:ss"
                    defaultValue={new Date(editData?.isoStartTime)}
                    caretAs={FaClock}
                    {...field}
                  />
                )}
                name="startTime"
              />

              {errors?.startTime && (
                <p style={{ color: "red" }} role="alert">
                  {errors?.startTime.message}
                </p>
              )}
            </Form.Group>

            <Form.Group>
              <Form.ControlLabel>End Time</Form.ControlLabel>
              <Controller
                control={control}
                rules={
                  {
                    // required: 'this field is required'
                  }
                }
                render={({ field }) => (
                  <DatePicker
                    format="HH:mm:ss"
                    defaultValue={new Date(editData?.isoEndTime)}
                    caretAs={FaClock}
                    {...field}
                  />
                )}
                name="endTime"
              />

              {errors?.endTime && (
                <p style={{ color: "red" }} role="alert">
                  {errors?.endTime.message}
                </p>
              )}
            </Form.Group>
          </Stack>

          <Form.Group>
            <Form.ControlLabel>Location</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => (
                <Form.Control name="location" {...field} type="text" />
              )}
              name="location"
            />

            {errors.location && (
              <p style={{ color: "red" }} role="alert">
                {errors.location.message}
              </p>
            )}
          </Form.Group>

          <Form.Group>
            <Form.ControlLabel>Description</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: "this field is required",
              }}
              render={({ field }) => (
                <Form.Control name="description" {...field} type="text" />
              )}
              name="description"
            />

            {errors.description && (
              <p style={{ color: "red" }} role="alert">
                {errors.description.message}
              </p>
            )}
          </Form.Group>

          <Stack
            justifyContent="space-between"
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 15,
            }}
          >
            <Form.Group>
              <Form.ControlLabel>featuredArtists</Form.ControlLabel>

              <Controller
                control={control}
                rules={
                  {
                    // required: 'this field is required'
                  }
                }
                render={({ field }) => (
                  <CheckPicker
                    data={artists?.map((item) => {
                      return {
                        label: item.name,
                        value: item._id,
                      };
                    })}
                    style={{ width: 224 }}
                    {...field}
                  />
                )}
                name="featuredArtists"
              />

              {errors.featuredArtists && (
                <p style={{ color: "red" }} role="alert">
                  {errors.featuredArtists.message}
                </p>
              )}
            </Form.Group>
          </Stack>

          <Stack
            spacing={12}
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 2,
            }}
          >
            <ImageUploader limit={5} editData={editData} />
          </Stack>

          <div className="row" style={{ marginTop: 10 }}>
            <Button type="submit" appearance="primary">
              Submit
            </Button>
          </div>
        </Form>
      </Drawer.Body>
    </Drawer>
  );
};

export default EditDrawerView;
