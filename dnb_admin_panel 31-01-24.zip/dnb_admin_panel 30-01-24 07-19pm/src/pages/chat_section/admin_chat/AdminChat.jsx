import useAxiosPrivate from '@/hooks/useAxiosPrivate';
import { useQuery } from '@tanstack/react-query';
import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom';
import { Button } from 'rsuite';
import DrawerView from './DrawerView';

const AdminChat = () => {
    const [showDrawer, setShowDrawer] = useState(false);
    const [editOpen, setEditOpen] = useState(false);
    const [deleteOpen, setDeleteOpen] = useState(false);

    const [data, setData] = useState([]);

    const [page, setPage] = useState(1);
    const [limit, setLimit] = useState(10);
    const [total, setTotal] = useState(0);


    const axiosPrivate = useAxiosPrivate();
    const [search] = useSearchParams()
    const roomId = search.get('roomId')
    const { data: adminChats, isLoading, refetch } = useQuery({
        queryKey: ["get-admin-chats", roomId],
        queryFn: () => axiosPrivate.get(`chat/get-admin-chats?page=${page}&limit=${limit}&roomId=${roomId}`),
        select: (res) => res?.data?.data,
        enabled: false
    });


    useEffect(() => {

        if (adminChats?.result?.length > 0) {
            setData(adminChats.result)
            setTotal(adminChats.paginate?.totalResults)

        } else {
            setData([])
            setTotal(0)

        }


    }, [adminChats])



    useEffect(() => {
        refetch()
    }, [showDrawer, page, limit, editOpen, deleteOpen, roomId]);






    return (
        <div>

            <div className="container">
                {
                    data?.map((item) => {

                        return (

                            <div className="row">
                                <div className="col-sm-8">
                                    <div>
                                        <img src={`${item.image}`} width={100} height={100} />

                                    </div>
                                    {item.chatName}

                                </div>
                            </div>


                        )


                    })


                }





            </div>



            <DrawerView open={showDrawer} roomId={roomId} onClose={() => setShowDrawer(false)} />

        </div>
    )
}

export default AdminChat