import React, { useEffect, useState } from "react";
import {
  Input,
  InputGroup,
  Table,
  Button,
  DOMHelper,
  Progress,
  Checkbox,
  Stack,
  SelectPicker,
  Pagination,
  Modal,
} from "rsuite";
import SearchIcon from "@rsuite/icons/Search";
import MoreIcon from "@rsuite/icons/legacy/More";
import DrawerView from "./DrawerView";
import { mockUsers } from "@/data/mock";
import { NameCell, ImageCell, CheckCell, ActionCell } from "./Cells";
import { useMutation, useQuery } from "@tanstack/react-query";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import EditDrawerView from "./EditDrawerView";
import DelteModal from "."
import DeleteModal from "./DeleteRow";
import dayjs from "dayjs";
import { useLocation, useSearchParams } from "react-router-dom";
const { Column, HeaderCell, Cell } = Table;
const { getHeight } = DOMHelper;

const DataTable = (props) => {
  const [showDrawer, setShowDrawer] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const [checkedKeys, setCheckedKeys] = useState<number[]>([]);
  const [sortColumn, setSortColumn] = useState();
  const [sortType, setSortType] = useState();
  const [searchKeyword, setSearchKeyword] = useState("");
  const [editData, setEditData] = useState({});
  const [data, setData] = useState([]);

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [total, setTotal] = useState(0);

  const [rating, setRating] = useState<number | null>(null);
  const axiosPrivate = useAxiosPrivate();
  const [search] = useSearchParams()
  const roomId = search.get('roomId')
  const { data: adminChats, isLoading, refetch } = useQuery({
    queryKey: ["get-admin-chats", roomId],
    queryFn: () => axiosPrivate.get(`chat/get-admin-chats?page=${page}&limit=${limit}&roomId=${roomId}`),
    select: (res) => res?.data?.data,
    enabled: false
  });


  useEffect(() => {

    if (adminChats?.result?.length > 0) {
      setData(adminChats.result)
      setTotal(adminChats.paginate?.totalResults)

    } else {
      setData([])
      setTotal(0)

    }


  }, [adminChats])



  useEffect(() => {
    refetch()
  }, [showDrawer, page, limit, editOpen, deleteOpen, roomId]);

  let checked = false;
  let indeterminate = false;

  if (checkedKeys?.length === data?.length) {
    checked = true;
  } else if (checkedKeys?.length === 0) {
    checked = false;
  } else if (checkedKeys?.length > 0 && checkedKeys?.length < data?.length) {
    indeterminate = true;
  }

  const handleChangeLimit = (dataKey) => {
    setPage(1);
    setLimit(dataKey);
  };

  const handleCheckAll = (_value, checked) => {
    const keys = checked ? data.map((item) => item?._id) : [];
    setCheckedKeys(keys);
  };
  const handleCheck = (value, checked) => {
    const keys = checked
      ? [...checkedKeys, value]
      : checkedKeys.filter((item) => item !== value);
    setCheckedKeys(keys);
  };

  const handleSortColumn = (sortColumn, sortType) => {
    setSortColumn(sortColumn);
    setSortType(sortType);
  };

  const filteredData = () => {
    const filtered = data?.filter((item) => {
      if (!item?.chatName?.includes(searchKeyword)) {
        return false;
      }
      return true;
    })?.map((map_item) => { return { ...map_item, roomName: map_item?.roomDetails?.name, roomId: map_item?.roomDetails?._id } })
    if (sortColumn && sortType) {
      return filtered.sort((a, b) => {
        let x: any = a[sortColumn];
        let y: any = b[sortColumn];

        if (typeof x === "string") {
          x = x.charCodeAt(0);
        }
        if (typeof y === "string") {
          y = y.charCodeAt(0);
        }

        if (sortType === "asc") {
          return x - y;
        } else {
          return y - x;
        }
      });
    }
    return filtered;
  };

  console.log(data);

  return (
    <div className="container">

      <div className="row">
        <div className="col-sm-8">
        </div>
        <div className="col-sm-4">

          <Button appearance="primary" onClick={() => setShowDrawer(true)}>
            Add Chat
          </Button>
        </div>

      </div>

      {/* <Table
        height={Math.max(getHeight(window) - 200, 400)}
        data={filteredData()}
        sortColumn={sortColumn}
        sortType={sortType}
        onSortColumn={handleSortColumn}
        loading={isLoading}
      >
        

        <Column width={50} fixed>
          <HeaderCell style={{ padding: 0 }}>
            <div style={{ lineHeight: "40px" }}>
              <Checkbox
                inline
                checked={checked}
                indeterminate={indeterminate}
                onChange={handleCheckAll}
              />
            </div>
          </HeaderCell>
          <CheckCell
            dataKey="_id"
            checkedKeys={checkedKeys}
            onChange={handleCheck}
          />
        </Column>

        <Column width={300}>
          <HeaderCell>Image</HeaderCell>
          <ImageCell dataKey="image" />
        </Column>

        <Column width={300}>
          <HeaderCell>Room Name</HeaderCell>
          <Cell dataKey="roomName" />
        </Column>
        <Column width={300}>
          <HeaderCell>Chat Name</HeaderCell>
          <NameCell dataKey="chatName" />
        </Column>



        <Column width={120}>
          <HeaderCell>Action</HeaderCell>
          <ActionCell
            dataKey="id"
            editData={editData}
            setEditData={setEditData}
            editOpen={editOpen}
            setEditOpen={setEditOpen}
            deleteOpen={deleteOpen}
            setDeleteOpen={setDeleteOpen}
          />
        </Column>
      </Table> */}


      {
        data?.map((item) => {

          return (

            <div className="row">
              <div className="col-sm-8 mt-5">
                <div>
                  <img src={`${item?.image}`} width={100} height={100} />

                </div>
                <div>
                  {item?.chatName}

                </div>
                <p>
                  {item?.description}
                </p>

              </div>
            </div>


          )


        })


      }







      <div style={{ padding: 20 }}>
        <Pagination
          prev
          next
          first
          last
          ellipsis
          boundaryLinks
          maxButtons={5}
          size="xs"
          layout={["total", "-", "limit", "|", "pager", "skip"]}
          total={total}
          limitOptions={[10, 20, 30, 40, 50]}
          limit={limit}
          activePage={page}
          onChangePage={setPage}
          onChangeLimit={handleChangeLimit}
        />
      </div>

      <DrawerView open={showDrawer} onClose={() => setShowDrawer(false)} />
      <EditDrawerView
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editData={editData}
        setEditData={setEditData}
      />
      <DeleteModal open={deleteOpen}
        handleClose={() => setDeleteOpen(false)} deleteType="chat" editData={editData} />
    </div>
  );
};

export default DataTable;
