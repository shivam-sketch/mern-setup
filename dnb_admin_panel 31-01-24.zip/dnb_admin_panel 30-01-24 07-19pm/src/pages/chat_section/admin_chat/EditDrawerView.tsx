import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import api from "@/lib/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import Dropzone from "react-dropzone";
import { Controller, useForm } from "react-hook-form";
import { FaClock } from "react-icons/fa";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker,
  DatePicker,
} from "rsuite";

const EditDrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const [isUploaded, setIsUploaded] = useState(false)
  const [images, setImages] = useState([])
  const [imagesUrl, setImagesUrl] = useState([])

  const { onClose, editData, setEditData, setEditOpen, ...rest } = props;


  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    watch
  } = useForm({
    defaultValues: {},
  });




  // rooms
  const { data: rooms } = useQuery({
    queryKey: ["get-all-rooms"],
    queryFn: () => axiosPrivate.get(`common/get-all-rooms`),
    select: (res) => res?.data?.data,
  });


  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/chat/edit-admin-chat", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        cogoToast.success("Admin Chat Edited");

        onClose();
      }
    },
  });


  const { mutate: uploadImages } = useMutation({
    mutationFn: (data) => {
      const headers = {
        headers: { 'Content-Type': 'multipart/form-data' },
      }

      return axiosPrivate.post("/web/upload-images", data, headers)
    },


    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {

        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);

      }

    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        setImagesUrl(data?.data?.data?.name)
        setImages([])
        cogoToast.success('Images Uploaded')
        setIsUploaded(true)
      }
    },

  });





  useEffect(() => {
    if (editData) {
      setValue("roomId", editData.roomId);
      setValue("chatName", editData.chatName);
      setValue("description", editData.description);

    }

  }, [editData]);






  const onImagesUpload = (files) => {
    // console.log(files)
    if (files?.length > 1) {
      cogoToast.error('Only 1 image is allowed')
    } else {

      let tempImages = { ...images, ...files }
      setImages([...tempImages])
    }



  }



  const onSubmit = (data) => {
    if (images?.length > 0 && imagesUrl?.length == 0) {
      cogoToast.error('Images Not Uploaded')

    } else {

      let body = {
        ...data, id: editData._id
      }
      if (imagesUrl?.length > 0) {
        body['image'] = imagesUrl[0]
      }

      mutate(body)

    }


  }

  const handleImagesSubmit = () => {
    if (images?.length == 0) {
      cogoToast.error('images not selected')
      return
    }

    const fd = new FormData()
    images?.forEach((item) => {
      console.log(item)
      fd.append('image', item[0])

    })

    uploadImages(fd)


  }




  console.log(editData);

  return (
    <Drawer backdrop="static" size="sm" placement="right" onClose={onClose} {...rest}>
      <Drawer.Header>
        <Drawer.Title>Edit Admin Chat</Drawer.Title>
        <Drawer.Actions>

          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)} >



          <Form.Group>
            <Form.ControlLabel>Rooms</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                // required: 'this field is required'
              }}
              render={({ field }) => (


                <SelectPicker data={rooms?.map((item) => {
                  return {
                    label: item?.name, value: item._id
                  }
                })} style={{ width: 224 }} {...field} />


              )}
              name="roomId"
            />

            {errors.roomId && <p style={{ color: 'red' }} role="alert">{errors.roomId.message}</p>}

          </Form.Group>




          <Form.Group>
            <Form.ControlLabel>Chat Name</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: 'this field is required'

              }}
              render={({ field }) => (

                <Form.Control name="chatName"  {...field} />
              )}
              name="chatName"
            />

            {errors.chatName && <p style={{ color: 'red' }} role="alert">{errors.chatName.message}</p>}


          </Form.Group>


          <Form.Group>
            <Form.ControlLabel>Chat Description</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                required: 'this field is required'

              }}
              render={({ field }) => (

                <Form.Control name="description"  {...field} />
              )}
              name="description"
            />

            {errors.description && <p style={{ color: 'red' }} role="alert">{errors.description.message}</p>}


          </Form.Group>



          <div>




            <Dropzone onDrop={onImagesUpload}>
              {({ getRootProps, getInputProps }) => (
                <section>
                  <div {...getRootProps()} style={{ border: '2px solid #3c3f43', height: 100, padding: '10px' }}>
                    <input {...getInputProps()} />
                    <p >Drag 'n' drop some images here, or click to select images</p>
                    {images?.length > 0 ? (
                      <>
                        {
                          images?.map((item, index) => {
                            return (
                              <img src={`${URL.createObjectURL(item[0])}`} width={50} />

                            )
                          })
                        }

                      </>

                    ) : (<></>)}
                  </div>
                </section>
              )}
            </Dropzone>

          </div>

          <div className="row" style={{ marginTop: 10 }}>

            <Button appearance='primary' onClick={handleImagesSubmit} >
              Start Uploading


            </Button>
          </div>
          <div className="row" style={{ marginTop: 10 }}>



            <Button type='submit' appearance="primary" >
              Submit
            </Button>
          </div>
        </Form>
      </Drawer.Body>
    </Drawer >
  );
};

export default EditDrawerView;
