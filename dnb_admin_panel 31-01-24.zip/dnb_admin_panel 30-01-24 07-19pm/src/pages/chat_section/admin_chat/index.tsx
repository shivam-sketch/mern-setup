import React from 'react';
import { Breadcrumb, Panel } from 'rsuite';
import DataTable from './DataTable';
import AdminChat from './AdminChat';
// import './styles.less'
const Page = () => {
  return (
    <Panel
      header={
        <>
          <h3 className="title">Admin Chat</h3>

        </>
      }
    >
      <DataTable />
      {/* <AdminChat /> */}
    </Panel>
  );
};

export default Page;
