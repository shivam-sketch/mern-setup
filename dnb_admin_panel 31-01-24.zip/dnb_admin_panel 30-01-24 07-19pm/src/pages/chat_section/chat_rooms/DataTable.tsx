import React, { useEffect, useState } from "react";
import {
  Input,
  InputGroup,
  Table,
  Button,
  DOMHelper,
  Progress,
  Checkbox,
  Stack,
  SelectPicker,
  Pagination,
  Modal,
} from "rsuite";
import SearchIcon from "@rsuite/icons/Search";
import MoreIcon from "@rsuite/icons/legacy/More";
import DrawerView from "./DrawerView";
import { mockUsers } from "@/data/mock";
import { NameCell, ImageCell, CheckCell, ActionCell } from "./Cells";
import { useMutation, useQuery } from "@tanstack/react-query";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import EditDrawerView from "./EditDrawerView";
import DelteModal from "."
import DeleteModal from "./DeleteRow";
import dayjs from "dayjs";
const { Column, HeaderCell, Cell } = Table;
const { getHeight } = DOMHelper;

const DataTable = () => {
  const [showDrawer, setShowDrawer] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const [checkedKeys, setCheckedKeys] = useState<number[]>([]);
  const [sortColumn, setSortColumn] = useState();
  const [sortType, setSortType] = useState();
  const [searchKeyword, setSearchKeyword] = useState("");
  const [data, setData] = useState([]);
  const [editData, setEditData] = useState({});

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [total, setTotal] = useState(0);

  const [rating, setRating] = useState<number | null>(null);
  const axiosPrivate = useAxiosPrivate();

  const { data: rooms, isLoading, refetch } = useQuery({
    queryKey: ["get-rooms"],
    queryFn: () => axiosPrivate.get(`chat/get-rooms?page=${page}&limit=${limit}`),
    select: (res) => res?.data?.data,
    enabled: false
  });


  useEffect(() => {

    if (rooms?.result?.length > 0) {
      setData(rooms.result)
      setTotal(rooms.paginate?.totalResults)

    }


  }, [rooms])

  console.log(rooms)

  useEffect(() => {
    refetch()
  }, [showDrawer, page, limit, editOpen, deleteOpen]);

  let checked = false;
  let indeterminate = false;

  if (checkedKeys?.length === data?.length) {
    checked = true;
  } else if (checkedKeys?.length === 0) {
    checked = false;
  } else if (checkedKeys?.length > 0 && checkedKeys?.length < data?.length) {
    indeterminate = true;
  }

  const handleChangeLimit = (dataKey) => {
    setPage(1);
    setLimit(dataKey);
  };

  const handleCheckAll = (_value, checked) => {
    const keys = checked ? data.map((item) => item?._id) : [];
    setCheckedKeys(keys);
  };
  const handleCheck = (value, checked) => {
    const keys = checked
      ? [...checkedKeys, value]
      : checkedKeys.filter((item) => item !== value);
    setCheckedKeys(keys);
  };

  const handleSortColumn = (sortColumn, sortType) => {
    setSortColumn(sortColumn);
    setSortType(sortType);
  };

  const filteredData = () => {
    const filtered = data?.filter((item) => {
      if (!item?.name?.includes(searchKeyword)) {
        return false;
      }
      return true;
    })
    if (sortColumn && sortType) {
      return filtered.sort((a, b) => {
        let x: any = a[sortColumn];
        let y: any = b[sortColumn];

        if (typeof x === "string") {
          x = x.charCodeAt(0);
        }
        if (typeof y === "string") {
          y = y.charCodeAt(0);
        }

        if (sortType === "asc") {
          return x - y;
        } else {
          return y - x;
        }
      });
    }
    return filtered;
  };

  console.log(data);

  return (
    <>
      <Stack
        className="table-toolbar"
        justifyContent="space-between"
      >
        <Stack spacing={6}>
          {/* <SelectPicker
            label="Rating"
            data={ratingList}
            searchable={false}
            value={rating}
            onChange={setRating}
          /> */}
          <InputGroup inside>
            <Input
              placeholder="Search"
              value={searchKeyword}
              onChange={setSearchKeyword}
            />
            <InputGroup.Addon>
              <SearchIcon />
            </InputGroup.Addon>
          </InputGroup>
        </Stack>
        <Button appearance="primary" onClick={() => setShowDrawer(true)}>
          Add room
        </Button>

      </Stack>

      <Table
        height={Math.max(getHeight(window) - 200, 400)}
        data={filteredData()}
        sortColumn={sortColumn}
        sortType={sortType}
        onSortColumn={handleSortColumn}
        loading={isLoading}
      >
        {/* <Column width={50} align="center" fixed>
          <HeaderCell>Id</HeaderCell>
          <Cell dataKey="_id" />
        </Column> */}

        <Column width={50} fixed>
          <HeaderCell style={{ padding: 0 }}>
            <div style={{ lineHeight: "40px" }}>
              <Checkbox
                inline
                checked={checked}
                indeterminate={indeterminate}
                onChange={handleCheckAll}
              />
            </div>
          </HeaderCell>
          <CheckCell
            dataKey="_id"
            checkedKeys={checkedKeys}
            onChange={handleCheck}
          />
        </Column>
        <Column width={300}>
          <HeaderCell>Image</HeaderCell>
          <ImageCell dataKey="image" />
        </Column>
        <Column width={300}>
          <HeaderCell>Room Name</HeaderCell>
          <NameCell dataKey="name" />
        </Column>



        <Column width={120}>
          <HeaderCell>Action</HeaderCell>
          <ActionCell
            dataKey="id"
            editData={editData}
            setEditData={setEditData}
            editOpen={editOpen}
            setEditOpen={setEditOpen}
            deleteOpen={deleteOpen}
            setDeleteOpen={setDeleteOpen}
          />
        </Column>
      </Table>

      <div style={{ padding: 20 }}>
        <Pagination
          prev
          next
          first
          last
          ellipsis
          boundaryLinks
          maxButtons={5}
          size="xs"
          layout={["total", "-", "limit", "|", "pager", "skip"]}
          total={total}
          limitOptions={[10, 20, 30, 40, 50]}
          limit={limit}
          activePage={page}
          onChangePage={setPage}
          onChangeLimit={handleChangeLimit}
        />
      </div>

      <DrawerView open={showDrawer} onClose={() => setShowDrawer(false)} />
      <EditDrawerView
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editData={editData}
        setEditData={setEditData}
      />
      <DeleteModal open={deleteOpen}
        handleClose={() => setDeleteOpen(false)} deleteType="room" editData={editData}  />
    </>
  );
};

export default DataTable;
