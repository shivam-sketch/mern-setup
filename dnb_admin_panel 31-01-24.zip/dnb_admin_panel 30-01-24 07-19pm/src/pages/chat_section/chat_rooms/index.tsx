import React from 'react';
import { Breadcrumb, Panel } from 'rsuite';
import DataTable from './DataTable';
// import './styles.less'
const Page = () => {
  return (
    <Panel
      header={
        <>
          <h3 className="title">Room</h3>

        </>
      }
    >
      <DataTable />
    </Panel>
  );
};

export default Page;
