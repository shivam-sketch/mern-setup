import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import api from "@/lib/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import Dropzone from "react-dropzone";
import { Controller, useForm } from "react-hook-form";
import { FaClock } from "react-icons/fa";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker,
  DatePicker,
} from "rsuite";

const EditDrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const [isUploaded, setIsUploaded] = useState(false)
  const [images, setImages] = useState([])
  const [imagesUrl, setImagesUrl] = useState([])

  const { onClose, editData, setEditData, setEditOpen, ...rest } = props;


  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    watch
  } = useForm({
    defaultValues: {},
  });


  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/edit-room", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        cogoToast.success("Event Edited");

        onClose();
      }
    },
  });


  const { mutate: uploadImages } = useMutation({
    mutationFn: (data) => {
      const headers = {
        headers: { 'Content-Type': 'multipart/form-data' },
      }

      return axiosPrivate.post("/web/upload-images", data, headers)
    },


    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {

        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);

      }

    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        setImagesUrl(data?.data?.data?.name)
        setImages([])
        cogoToast.success('Images Uploaded')
        setIsUploaded(true)
      }
    },

  });





  useEffect(() => {
    if (editData) {
      setValue("name", editData.name);
    }

  }, [editData]);






  const onSubmit = (data) => {


    let body = {
      ...data, id: editData._id
    }
    if (imagesUrl?.length > 0) {

      body['image'] = imagesUrl[0]
    }

    mutate(body)
  };

  const onImagesUpload = (files) => {
    // console.log(files)
    let tempImages = { ...images, ...files }
    if (tempImages?.length > 1) {
      cogoToast.error('Only 1 image is allowed')
    } else {

      setImages([...tempImages])
    }



  }


  const handleImagesSubmit = () => {
    if (images?.length == 0) {
      cogoToast.error('images not selected')
      return
    }

    const fd = new FormData()
    images?.forEach((item) => {
      console.log(item)
      fd.append('image', item[0])

    })

    uploadImages(fd)


  }




  console.log(editData);

  return (
    <Drawer backdrop="static" size="sm" placement="right" onClose={onClose} {...rest}>
      <Drawer.Header>
        <Drawer.Title>Edit Room</Drawer.Title>
        <Drawer.Actions>

          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)} >
          <Stack justifyContent="space-between" style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 7 }}>
            <Form.Group>
              <Form.ControlLabel>Room Name</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: 'this field is required'

                }}
                render={({ field }) => (

                  <Form.Control name="name" {...field} />
                )}
                name="name"
              />

              {errors.name && <p style={{ color: 'red' }} role="alert">{errors.name.message}</p>}


            </Form.Group>
          </Stack>

          <Stack spacing={12} style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 2 }}>




            <Dropzone onDrop={onImagesUpload}>
              {({ getRootProps, getInputProps }) => (
                <section>
                  <div {...getRootProps()} style={{ border: '2px solid #3c3f43', height: 100 }}>
                    <input {...getInputProps()} />
                    <p>Drag 'n' drop some images here, or click to select images</p>
                    {images?.length > 0 ? (
                      <>
                        {
                          images?.map((item, index) => {
                            return (
                              <img src={`${URL.createObjectURL(item[0])}`} width={50} />

                            )
                          })
                        }

                      </>

                    ) : (<></>)}
                  </div>
                </section>
              )}
            </Dropzone>

          </Stack>
          <div className="row" style={{ marginTop: 10 }}>

            <Button appearance='primary' onClick={handleImagesSubmit} >
              Start Uploading


            </Button>
          </div>
          <div className="row" style={{ marginTop: 10 }}>



            <Button type='submit' appearance="primary">
              Submit
            </Button>
          </div>
        </Form>
      </Drawer.Body>
    </Drawer >
  );
};

export default EditDrawerView;
