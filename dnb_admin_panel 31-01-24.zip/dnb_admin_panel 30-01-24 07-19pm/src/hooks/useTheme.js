import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useLocalStorage } from "./useLocalStorage";
import { useCookies } from "./useCookies";

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [user, setUser] = useLocalStorage("user", null);
  // const [cookie, setCookie] = useCookies("token", null);
  const [mobile, setMobile] = useState(false);
  const [auth, setAuth] = useState(null);

  const navigate = useNavigate();

  const login = async data => {
    let { token, _id, ...rest } = data
    setUser(rest);
    // setCookie(data.token);
    setAuth({ token: data.token })
    navigate("/", { replace: true });
  };

  const logout = () => {
    setUser(null);
    // setCookie(null);
    navigate("/sign-in", { replace: true });
  };

  const handleResize = () => {
    if (window.innerWidth < 920) {
      setMobile(true);
    } else {
      setMobile(false);
    }
  };
  // create an event listener
  useEffect(() => {
    if (window.innerWidth < 920) {
      setMobile(true);
    }
    window.addEventListener("resize", handleResize);
  }, []);

  const value = useMemo(
    () => ({
      user,
      login,
      logout,
      mobile,
      setUser,
      setAuth, auth
    }),
    [user, auth]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => {
  return useContext(ThemeContext);
};
