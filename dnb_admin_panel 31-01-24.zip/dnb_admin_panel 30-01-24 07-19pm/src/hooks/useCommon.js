import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useLocalStorage } from "./useLocalStorage";
import { useCookies } from "./useCookies";
import useAxiosPrivate from "./useAxiosPrivate"
import cogoToast from "cogo-toast";
const CommonContext = createContext();

export const CommonProvider = ({ children }) => {
  const [images, setImages] = useState([])
  const [imagesUrl, setImagesUrl] = useState([])
  const [isUploaded, setIsUploaded] = useState(false)


  const navigate = useNavigate();



  const value = useMemo(
    () => ({
      images,
      setImages,
      imagesUrl,
      setImagesUrl,
      isUploaded,
      setIsUploaded
    }),
    [images, imagesUrl, isUploaded]
  );

  return <CommonContext.Provider value={value}>{children}</CommonContext.Provider>;
};

export const useCommon = () => {
  return useContext(CommonContext);
};
