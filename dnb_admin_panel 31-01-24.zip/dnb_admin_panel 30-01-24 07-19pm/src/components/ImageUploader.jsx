import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import { useCommon } from "@/hooks/useCommon";
import { useMutation } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import React from "react";
import Dropzone from "react-dropzone";
import { Button } from "rsuite";

const ImageUploader = ({ limit = 5, editData }) => {
  const axiosPrivate = useAxiosPrivate();
  const {
    images,
    setImages,
    imagesUrl,
    setImagesUrl,
    isUploaded,
    setIsUploaded,
  } = useCommon();

  const { mutate: uploadImages } = useMutation({
    mutationFn: (data) => {
      const headers = {
        headers: { "Content-Type": "multipart/form-data" },
      };

      return axiosPrivate.post("/web/upload-images", data, headers);
    },

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        let tempurls = [...imagesUrl, ...data?.data?.data?.name];
        setImagesUrl(tempurls);
        setImages([]);
        cogoToast.success("Images Uploaded");
        setIsUploaded(true);
      }
    },
  });

  const onImagesUpload = (files) => {
    // console.log(files)
    setIsUploaded(true);
    let tempImages = [...images, ...files];
    if (tempImages?.length > parseInt(limit)) {
      cogoToast.error("max 5 images are allowed");
    } else {
      setImages([...tempImages]);
    }
  };

  const handleImagesSubmit = () => {
    if (images?.length == 0) {
      cogoToast.error("images not selected");
      return;
    }

    const fd = new FormData();
    images?.forEach((item) => {
      console.log(item);
      fd.append("image", item);
    });

    uploadImages(fd);
  };
  console.log(images);

  return (
    <>
      <Dropzone onDrop={onImagesUpload}>
        {({ getRootProps, getInputProps }) => (
          <section>
            <div
              {...getRootProps()}
              style={{ border: "2px solid #3c3f43", height: 100 }}
            >
              <input {...getInputProps()} />
              <p>Drag 'n' drop some images here, or click to select images</p>

              {images?.length > 0 ? (
                <>
                  {images?.map((item, index) => {
                    return (
                      <img src={`${URL.createObjectURL(item)}`} width={50} />
                    );
                  })}
                </>
              ) : (
                <></>
              )}

              {editData?.image?.length > 0 && limit > 1 ? (
                <>
                  {editData?.image?.map((item, index) => {
                    return <img src={item} width={50} />;
                  })}
                </>
              ) : (
                <>
                  <img src={editData?.image} width={50} />
                </>
              )}
            </div>
          </section>
        )}
      </Dropzone>
      <div className="row">
        <Button appearance="primary" onClick={handleImagesSubmit}>
          Start Uploading
        </Button>
      </div>
    </>
  );
};

export default ImageUploader;
