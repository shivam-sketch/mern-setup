import React, { useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import { IntlProvider } from "react-intl";
import { CustomProvider } from "rsuite";
import enGB from "rsuite/locales/en_GB";
import locales from "./locales";
import Frame from "./components/Frame";
import DashboardPage from "./pages/dashboard";
import Error404Page from "./pages/authentication/404";
import Error403Page from "./pages/authentication/403";
import Error500Page from "./pages/authentication/500";
import Error503Page from "./pages/authentication/503";
import HomeLayout from "@/components/HomeLayout";
import SignInPage from "./pages/authentication/sign-in";
import SignUpPage from "./pages/authentication/sign-up";
import MembersPage from "./pages/tables/members";
import VirtualizedTablePage from "./pages/tables/virtualized";
import FormBasicPage from "./pages/forms/basic";
import FormWizardPage from "./pages/forms/wizard";
import CalendarPage from "./pages/calendar";
import { appNavs } from "./config";
import Users from "./pages/user_management";
import Events from "./pages/events_management";

import PrivacyPolicy from "./pages/static_content/privacy_policy";
import TermsAndCondition from "./pages/static_content/terms_and_conditions";
import AboutUs from "./pages/static_content/about_us";
import Help from "./pages/help_section";
import Artists from "./pages/artists_section";
import ChatRoom from "./pages/chat_section/chat_rooms";
import AdminChat from "./pages/chat_section/admin_chat";



import AddFeatured from "./pages/featured_section";
import ReadPrivacyPolicy from "./pages/static_content/privacy_policy/ReadPrivacyPolicy";
import ReadTermsAndConditions from "./pages/static_content/terms_and_conditions/ReadTermsAndConditions";
import ReadAboutUs from "./pages/static_content/about_us/ReadAboutUs";

import { io } from "socket.io-client";
import { socketEndPoint } from "./lib/api";



const App = () => {




  return (
    <IntlProvider locale="en" messages={locales.en}>
      <CustomProvider theme="dark" locale={enGB}>
        <Routes>
          <Route path="privacy-policy" element={<ReadPrivacyPolicy />} />
          <Route path="terms-and-conditions" element={<ReadTermsAndConditions />} />
          <Route path="about-us" element={<ReadAboutUs />} />



          <Route element={<HomeLayout />}>
            <Route path="sign-in" element={<SignInPage />} />
            <Route path="sign-up" element={<SignUpPage />} />
          </Route>
          <Route path="/" element={<Frame navs={appNavs} />}>
            <Route index element={<DashboardPage />} />
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="/users" element={<Users />} />
            <Route path="/events" element={<Events />} />
            <Route path="/artists" element={<Artists />} />
            <Route path="/chat-rooms" element={<ChatRoom />} />
            <Route path="/admin-chat" element={<AdminChat />} />



            <Route path="table-members" element={<MembersPage />} />
            <Route
              path="table-virtualized"
              element={<VirtualizedTablePage />}
            />
            <Route path="error-404" element={<Error404Page />} />
            <Route path="error-403" element={<Error403Page />} />
            <Route path="error-500" element={<Error500Page />} />
            <Route path="error-503" element={<Error503Page />} />
            <Route path="form-basic" element={<FormBasicPage />} />
            <Route path="form-wizard" element={<FormWizardPage />} />
            <Route path="calendar" element={<CalendarPage />} />
            <Route path="add-about-us" element={<AboutUs />} />

            <Route path="add-privacy-policy" element={<PrivacyPolicy />} />
            <Route path="add-terms-and-conditions" element={<TermsAndCondition />} />
            <Route path="help" element={<Help />} />
            <Route path="add-featured" element={<AddFeatured />} />




          </Route>
          <Route path="*" element={<Error404Page />} />
        </Routes>
      </CustomProvider>
    </IntlProvider>
  );
};

export default App;
