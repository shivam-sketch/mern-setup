import React from 'react';
// import ReactDOM from 'react-dom/client';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import {
  useQuery,
  useMutation,
  useQueryClient,
  QueryClient,
  QueryClientProvider,
} from '@tanstack/react-query'
import './styles/index.less';
import { AuthProvider } from './hooks/useAuth';
import { CommonProvider } from './hooks/useCommon';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnMount: false,
      refetchOnWindowFocus: false,
      networkMode: "always",
    },
  },
});
const root = createRoot(document.getElementById('root'));

root.render(
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <AuthProvider>
        <CommonProvider>
          <App />
        </CommonProvider>
      </AuthProvider>
    </BrowserRouter>
  </QueryClientProvider>
);
