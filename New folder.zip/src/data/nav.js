import DashboardIcon from "@rsuite/icons/Dashboard";
import GridIcon from "@rsuite/icons/Grid";

export const nav = [
  {
    title: "Dashboard",
    link: "/",
    icon: <DashboardIcon />,
  },
  {
    title: "Home Page Master",
    icon: <GridIcon />,
    menu: [
      {
        title: "Home Slider",
        link: "/home-slider",
      },
    ],
  },
];
