import { lazy } from "react";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const HomeSlider = lazy(() => import("./pages/homeslider/HomeSlider"));

const routes = [
  { path: "/", exact: true, name: "Dashboard", element: Dashboard },
  { path: "/home-slider", name: "Home Slider", element: HomeSlider },
];

export default routes;
