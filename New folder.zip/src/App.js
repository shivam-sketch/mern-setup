import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "rsuite/dist/rsuite.min.css";
import "leaflet/dist/leaflet.css";
import "react-quill/dist/quill.snow.css";
import { Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import ProtectedLayout from "./components/ProtectedLayout";
import HomeLayout from "./components/HomeLayout";
import { Loader } from "rsuite";

const loading = (
  <div className="fullLoader">
    <Loader />
  </div>
);
const Login = lazy(() => import("./pages/Login"));

function App() {
  return (
    <Suspense fallback={loading}>
      <Routes>
        <Route element={<HomeLayout />}>
          <Route path="/login" element={<Login />} />
        </Route>
        <Route path="*" element={<ProtectedLayout />} />
      </Routes>
    </Suspense>
  );
}

export default App;
