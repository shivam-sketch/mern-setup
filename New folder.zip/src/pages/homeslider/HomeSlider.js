import React, { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  Dropdown,
  IconButton,
  Loader,
  Popover,
  SelectPicker,
  Table,
  Whisper,
} from "rsuite";
import api, { imageUrl } from "lib/api";
import { AiOutlineDelete, AiOutlineEye } from "react-icons/ai";
import AddHomeSlider from "./component/AddHomeSlider";
import ViewHomeSlider from "./component/ViewHomeSlider";
import DeleteHomeSlider from "./component/DeleteHomeSlider";
import { CgMore } from "react-icons/cg";
import { FaRegPlusSquare, FaRegMinusSquare } from "react-icons/fa";
import { FiMoreHorizontal } from "react-icons/fi";
import moment from "moment";

const { Column, HeaderCell, Cell } = Table;

const ImageCell = ({ rowData, dataKey, ...props }) => (
  <Cell {...props}>
    <div
      style={{
        overflow: "hidden",
        display: "flex",
        justifyContent: "center",
        alignItemsk: "center",
      }}
    >
      <img
        src={`${imageUrl}images/sliderImage/${rowData.sliderImage}`}
        width="60"
      />
    </div>
  </Cell>
);

const ActionCell = ({
  setDeleteId,
  setDeleteOpen,
  rowData,
  dataKey,
  setViewOpen,
  setViewData,
  ...props
}) => {
  const renderMenu = ({ onClose, left, top, className }, ref) => {
    return (
      <Popover ref={ref} className={className} style={{ left, top }} full>
        <Dropdown.Menu>
          <Dropdown.Item
            onClick={() => {
              setDeleteId(rowData.id);
              setDeleteOpen(true);
            }}
          >
            Delete
          </Dropdown.Item>
          <Dropdown.Item
            onClick={() => {
              setViewOpen(true);
              setViewData(rowData);
            }}
          >
            View Slider
          </Dropdown.Item>
        </Dropdown.Menu>
      </Popover>
    );
  };

  return (
    <Cell {...props} className="link-group">
      <Whisper placement="autoVerticalEnd" trigger="click" speaker={renderMenu}>
        <IconButton appearance="subtle" icon={<FiMoreHorizontal />} />
      </Whisper>
    </Cell>
  );
};

const ToolTipCell = ({ rowData, dataKey, ...props }) => {
  const speaker = (
    <Popover>
      <p>{rowData[dataKey]}</p>
    </Popover>
  );

  return (
    <Cell {...props}>
      <Whisper placement="top" speaker={speaker}>
        <a>{rowData[dataKey]}</a>
      </Whisper>
    </Cell>
  );
};

const HomeSlider = () => {
  const [addFormOpen, setAddFormOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const [citiesData, setCitiesData] = useState([]);
  const [city, setCity] = useState(0);

  const [deleteId, setDeleteId] = useState(0);
  const [viewData, setViewData] = useState({});

  const { mutate: getSearchCitites, isLoading: citiesLoading } = useMutation(
    ["get-searched-cities"],
    (data) => api.post("/get-searched-cities", data),
    {
      onSuccess: (res) => {
        setCitiesData(res.data);
      },
      onError: (res) => {
        console.log(res.data);
      },
    }
  );

  const {
    isLoading: getSliderLoading,
    data: sliderData,
    refetch,
  } = useQuery(
    ["get-home-slider", city],
    () => api.get(`get-home-slider?cityId=${city}`),
    {
      select: (res) => res.data,
    }
  );

  const data =
    sliderData &&
    sliderData.map((item, i) => {
      return {
        id: item.id,
        sno: i + 1,
        city: item.cityName ?? "Global",
        startTime: moment(item.startTime).format("DD-MM-YYYY"),
        endTime: moment(item.endTime).format("DD-MM-YYYY"),
        shopCategory: item?.categoryName,
        productCategory: item?.productCategoryName,
        brandName: item?.brandName,
        product: item.productName,
        shop: item.shopId ? `${item?.shopNumber} - ${item?.shopName}` : "",
        image: (
          <img
            src={`${imageUrl}images/sliderImage/${item.sliderImage}`}
            width="60"
          />
        ),
        action: (
          <div className="d-flex">
            <button
              onClick={() => {
                setViewOpen(true);
                setViewData(item);
              }}
              className="btn btn-sm btn-primary ms-2"
            >
              View
            </button>
            <button
              className="btn btn-sm btn-primary ms-2"
              onClick={() => {
                setDeleteId(item.id);
                setDeleteOpen(true);
              }}
            >
              Delete
            </button>
          </div>
        ),
      };
    });

  const renderMenu = (menu) => {
    if (citiesLoading) {
      return (
        <div style={{ padding: 4, color: "#999", textAlign: "center" }}>
          <Loader />
        </div>
      );
    }
    return menu;
  };

  return (
    <div>
      <AddHomeSlider
        addFormOpen={addFormOpen}
        setAddFormOpen={setAddFormOpen}
        refetch={refetch}
        citiesData={citiesData}
      />
      <ViewHomeSlider
        viewOpen={viewOpen}
        setViewOpen={setViewOpen}
        viewData={viewData}
      />
      <DeleteHomeSlider
        deleteOpen={deleteOpen}
        setDeleteOpen={setDeleteOpen}
        deleteId={deleteId}
        refetch={refetch}
      />
      <div className="bg-white p-2 mb-2 rounded shadow-sm">
        <div className="row">
          <div className="col-6">
            <SelectPicker
              data={citiesData.map((item) => {
                return { value: item.id, label: item.name };
              })}
              onSearch={(val) => {
                if (val.length > 4) {
                  getSearchCitites({ searchedCity: val });
                }
              }}
              value={city}
              onChange={setCity}
              renderMenu={renderMenu}
              placeholder="Search By City"
            />
          </div>
          <div className="col-6">
            <button
              onClick={() => setAddFormOpen(true)}
              className="btn btn-danger float-end"
            >
              Add New
            </button>
          </div>
        </div>
      </div>
      <div className="vh80">
        <Table
          fillHeight
          data={data}
          className="shadow-sm rounded"
          loading={getSliderLoading ? true : false}
        >
          <Column width={60} align="center">
            <HeaderCell>S.no</HeaderCell>
            <Cell dataKey="sno" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>City</HeaderCell>
            <Cell dataKey="city" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Start Time</HeaderCell>
            <Cell dataKey="startTime" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>End Time</HeaderCell>
            <Cell dataKey="endTime" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Shop Category</HeaderCell>
            <ToolTipCell dataKey="shopCategory" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Product Category</HeaderCell>
            <ToolTipCell dataKey="productCategory" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Product</HeaderCell>
            <ToolTipCell dataKey="product" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Brand Name</HeaderCell>
            <ToolTipCell dataKey="brandName" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Shop</HeaderCell>
            <ToolTipCell dataKey="shop" />
          </Column>
          <Column flexGrow={1} align="center">
            <HeaderCell>Image</HeaderCell>
            <Cell className="actionCell" dataKey="image" />
          </Column>
          <Column flexGrow={3 / 2} align="center">
            <HeaderCell>Action</HeaderCell>
            <Cell className="actionCell" dataKey="action" />
          </Column>
        </Table>
      </div>
    </div>
  );
};

export default HomeSlider;
