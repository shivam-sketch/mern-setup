import { FaTimesCircle } from "react-icons/fa";
import { Modal } from "rsuite";
import api, { imageUrl } from "lib/api";

const ViewHomeSlider = ({ viewData, viewOpen, setViewOpen }) => {
  return (
    <Modal size="sm" open={viewOpen}>
      <Modal.Header closeButton={false}>
        <Modal.Title>
          <div className="closeButton">
            <FaTimesCircle
              color="red"
              size={25}
              onClick={() => setViewOpen(false)}
            />
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="d-flex justify-content-center">
          <img
            width={400}
            src={`${imageUrl}images/sliderImage/${viewData?.sliderImage}`}
            alt="slider"
          />
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default ViewHomeSlider;
