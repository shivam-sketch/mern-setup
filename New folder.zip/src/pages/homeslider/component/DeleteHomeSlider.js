import { useMutation } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import { Button, Modal } from "rsuite";
import api, { imageUrl } from "lib/api";
import { AiOutlineDelete } from "react-icons/ai";
import { FaTimesCircle } from "react-icons/fa";

const DeleteHomeSlider = ({ deleteId, deleteOpen, setDeleteOpen, refetch }) => {
  const { mutate: deleteSlider } = useMutation(
    ["delete-home-slider"],
    (data) => api.post("/delete-home-slider", data),
    {
      onSuccess: (res) => {
        if (res.data.status === "success") {
          setDeleteOpen(false);
          cogoToast.success("Slider Deleted Successfully");
          refetch();
        }
      },
      onError: (res) => {
        console.log(res.data);
      },
    }
  );
  return (
    <Modal
      backdrop="static"
      size="xs"
      open={deleteOpen}
      onClose={() => setDeleteOpen(false)}
    >
      <Modal.Header closeButton={false}>
        <Modal.Title className="d-flex justify-content-between align-items-center">
          <div className="closeButton">
            <FaTimesCircle
              color="red"
              size={25}
              onClick={() => setDeleteOpen(false)}
            />
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="text-center">
          <AiOutlineDelete style={{ fontSize: "3rem", color: "red" }} />
          <p className="py-4">Are Your Sure You Want To Delete The Slider ?</p>
        </div>
      </Modal.Body>
      <Modal.Footer className="d-flex justify-content-center">
        <Button
          onClick={() => setDeleteOpen(false)}
          color="green"
          appearance="primary"
        >
          No
        </Button>
        <Button
          onClick={() => deleteSlider({ id: deleteId })}
          color="red"
          appearance="primary"
        >
          Yes
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default DeleteHomeSlider;
