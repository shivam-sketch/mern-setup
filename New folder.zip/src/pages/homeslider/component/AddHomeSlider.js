import { useMutation, useQuery } from "@tanstack/react-query";
import { DatePicker, Input, Loader, Modal, SelectPicker } from "rsuite";
import cogoToast from "cogo-toast";
import React, { useCallback, useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import api, { imageUrl } from "lib/api";
import moment from "moment";
import { FaTimesCircle } from "react-icons/fa";
import { HiUpload } from "react-icons/hi";

const AddHomeSlider = ({ addFormOpen, setAddFormOpen, refetch }) => {
  //   const [serverError, setServerError] = useState({});
  const [citiesData, setCitiesData] = useState([]);
  const [file, setFile] = useState({
    bytes: "",
    filename: "",
  });
  const [cropModal, setCropModal] = useState(false);
  const [croppedImage, setCroppedImage] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    control,
    watch,
    setValue,
    setError,
  } = useForm({
    defaultValues: {
      // startTime: new Date("2015-08-14T00:00:00-05:30"),
      startTime: new Date(Date.parse(moment().startOf("day").toString())),
      endTime: new Date(Date.parse(moment().endOf("day").toString())),
      sliderName: "",
      cityId: null,
      navigateTo: null,
      shopCategoryId: null,
    },
  });
  const image = watch("sliderImage");
  const cityId = watch("cityId");
  const shopId = watch("shopId");
  const shopCategoryId = watch("shopCategoryId");
  const productCategoryId = watch("productCategoryId");
  const navigateTo = watch("navigateTo");

  useEffect(() => {
    setValue("shopCategoryId", null);
    setValue("productCategoryId", null);
    setValue("brandId", null);
    setValue("shopId", null);
  }, [navigateTo]);

  useEffect(() => {
    setValue("productCategoryId", null);
    setValue("brandId", null);
    setValue("shopId", null);
  }, [shopCategoryId]);

  const { data: pageScreenData } = useQuery(
    ["page-screen-dropdown"],
    () => api.get(`page-screen-dropdown`),
    {
      select: (res) => res.data,
    }
  );

  const { data: shopCategoryData } = useQuery(
    ["get-shop-category-dropdown"],
    () => api.get(`get-shop-category-dropdown`),
    {
      select: (res) => res.data,
    }
  );

  const { data: productCategoryData } = useQuery(
    ["get-shop-product-category-dropdown", shopCategoryId],
    () => api.get(`get-shop-product-category-dropdown/${shopCategoryId}`),
    {
      select: (res) => res.data,
      enabled: shopCategoryId ? true : false,
    }
  );

  const { data: brandData } = useQuery(
    ["brand-dropdown", productCategoryId],
    () => api.get(`brand-dropdown/${productCategoryId}`),
    {
      select: (res) => res.data,
      enabled: productCategoryId ? true : false,
    }
  );

  const { mutate: getSearchCitites, isLoading: citiesLoading } = useMutation(
    ["get-searched-cities"],
    (data) => api.post("/get-searched-cities", data),
    {
      onSuccess: (res) => {
        setCitiesData(res.data);
      },
      onError: (res) => {
        console.log(res.data);
      },
    }
  );

  const { data: shopsData } = useQuery(
    ["get-shops-dropdown", shopCategoryId, cityId],
    () =>
      api.get(
        `get-shops-dropdown?shopCategoryId=${shopCategoryId}&cityId=${cityId}`
      ),
    {
      select: (res) => res.data,
      enabled: shopCategoryId ? true : false,
    }
  );

  const { data: productData } = useQuery(
    ["product-dropdown", shopId],
    () => api.get(`product-dropdown?shopId=${shopId}`),
    {
      select: (res) => res.data,
      enabled: shopId ? true : false,
    }
  );

  useEffect(() => {
    if (image && Object.keys(image).length !== 0) {
      setFile({
        bytes: image[0],
        filename: URL.createObjectURL(image[0]),
      });
      setCropModal(true);
    }
  }, [image]);

  // ADD NEW SLIDER
  const { mutate: addSlider, isLoading: addSliderLoading } = useMutation(
    ["add-home-slider"],
    (data) => api.post("add-home-slider", data),
    {
      onSuccess: (res) => {
        if (res.data.status === "success") {
          cogoToast.success("Slider Added Successfully");
          setAddFormOpen(false);
          refetch();
          reset();
          onClose();
        }
      },
      onError: (res) => {
        console.log(res.data);
      },
    }
  );

  const onSubmit = (data) => {
    console.log("data he", data);
    const fd = new FormData();
    fd.append("startTime", moment(data.startTime).format("YYYY-MM-DD HH:mm"));
    fd.append("endTime", moment(data.endTime).format("YYYY-MM-DD HH:mm"));
    fd.append("sliderName", data.sliderName ?? "");
    fd.append("cityId", data.cityId ?? 0);
    fd.append("pageId", data.navigateTo ?? 0);
    fd.append("shopCategoryId", data.shopCategoryId ?? 0);
    fd.append("productCategoryId", data.productCategoryId ?? 0);
    fd.append("productId", data.productId ?? 0);
    fd.append("brandId", data.brandId ?? 0);
    fd.append("shopId", data.shopId ?? 0);
    if (croppedImage) {
      fd.append("sliderImage", croppedImage, file.bytes.name);
    }
    addSlider(fd);
  };

  const onClose = useCallback(() => {
    setValue("serviceImage", null);
    setCropModal(false);
    setCroppedImage(null);
    setFile({
      bytes: "",
      filename: "",
    });
  }, []);

  const renderMenu = (menu) => {
    if (citiesLoading) {
      return (
        <div style={{ padding: 4, color: "#999", textAlign: "center" }}>
          <Loader />
        </div>
      );
    }
    return menu;
  };

  console.log("errors ", errors);

  return (
    <Modal backdrop="static" open={addFormOpen} size="md">
      <Modal.Header closeButton={false}>
        <Modal.Title className="d-flex justify-content-between align-items-center">
          <div className="closeButton">
            <FaTimesCircle
              color="red"
              size={25}
              onClick={() => setAddFormOpen(false)}
            />
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <form className="addHomeSlider" onSubmit={handleSubmit(onSubmit)}>
          <div className="row">
            <div className="col-md-6">
              {croppedImage ? (
                <>
                  <div>
                    <img
                      src={URL.createObjectURL(croppedImage)}
                      alt="sliderImage"
                      width={"100%"}
                      className="mb-2 rounded"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="sliderImage"
                      className="btn btn-sm btn-danger w-100"
                    >
                      Change Image
                    </label>
                  </div>
                </>
              ) : (
                <label
                  htmlFor="sliderImage"
                  className="uploadImageBox d-flex flex-column justify-content-center align-items-center"
                  style={{ width: "100%" }}
                >
                  <HiUpload size={100} />
                  Click here to upload image
                </label>
              )}
              <input
                hidden
                name="sliderImage"
                id="sliderImage"
                type="file"
                {...register("sliderImage", {
                  required: "Image is required",
                  validate: async (value) => {
                    const fileTypes = ["png", "jpg", "jpeg"];
                    const fileType = value[0].name.split(".")[1];
                    if (!fileTypes.includes(fileType)) {
                      return `Please upload a valid file format. (${fileTypes})`;
                    }
                  },
                })}
              />
              <div className="text-danger">{errors?.sliderImage?.message}</div>
            </div>
            <div className="col-md-6">
              <div className="row">
                <div className="col-md-12 form-group my-1">
                  <label htmlFor="startTime">Start Time</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <DatePicker
                        cleanable={false}
                        oneTap
                        format="yyyy-MM-dd HH:mm"
                        {...field}
                        placeholder="Enter Start Time"
                      />
                    )}
                    name="startTime"
                    control={control}
                    rules={{
                      required: "Thid field is required",
                    }}
                  />
                  <div className="text-danger">
                    {errors?.startTime?.message}
                  </div>
                </div>
                <div className="col-md-12 form-group my-1">
                  <label htmlFor="startTime">End Time</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <DatePicker
                        cleanable={false}
                        oneTap
                        format="yyyy-MM-dd HH:mm"
                        {...field}
                        placeholder="Enter End Time"
                      />
                    )}
                    name="endTime"
                    control={control}
                    rules={{
                      required: "This field is required",
                    }}
                  />
                  <div className="text-danger">{errors?.endTime?.message}</div>
                </div>
                <div className="col-md-12 col-sm-6 form-group my-1">
                  <label htmlFor="startTime">Slider Name</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <Input
                        type="text"
                        className="form-control"
                        placeholder="Enter Slider Name"
                        {...field}
                      />
                    )}
                    name="sliderName"
                    control={control}
                    rules={{
                      required: "This field is required",
                    }}
                  />
                  <div className="text-danger">
                    {errors?.sliderName?.message}
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 form-group my-1">
              <label htmlFor="section">City</label>
              <Controller
                render={({ field: { ref, ...field } }) => (
                  <SelectPicker
                    data={
                      citiesData.length > 0
                        ? citiesData.map((item) => {
                            return { value: item.id, label: item.name };
                          })
                        : []
                    }
                    cleanable={false}
                    onSearch={(val) => {
                      if (val.length > 4) {
                        getSearchCitites({ searchedCity: val });
                      }
                    }}
                    {...field}
                    renderMenu={renderMenu}
                    placeholder="Select City"
                  />
                )}
                name="cityId"
                control={control}
                // rules={{
                //   required: "This field is required",
                // }}
              />
              <div className="text-danger">{errors?.cityId?.message}</div>
            </div>
            <div className="col-md-6 form-group my-1">
              <label htmlFor="section">Select Page</label>
              <Controller
                render={({ field: { ref, ...field } }) => (
                  <SelectPicker
                    data={
                      pageScreenData
                        ? pageScreenData.map((item) => {
                            return {
                              value: item.id,
                              label: item.pageName,
                            };
                          })
                        : []
                    }
                    {...field}
                    style={{ width: "100%" }}
                    searchable={false}
                    placeholder="Select Page To Navigate"
                  />
                )}
                // rules={{
                //   required: "This field is required",
                // }}
                name="navigateTo"
                control={control}
              />
              <div className="text-danger">{errors?.navigateTo?.message}</div>
            </div>
            {navigateTo == 1 && (
              <>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Shop Category</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomEnd"
                        data={
                          shopCategoryData
                            ? shopCategoryData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.categoryName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Shop Category"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="shopCategoryId"
                    control={control}
                  />
                  <div className="text-danger">
                    {errors?.shopCategoryId?.message}
                  </div>
                </div>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Product Category</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomStart"
                        data={
                          productCategoryData
                            ? productCategoryData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.productCategoryName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Product Category"
                      />
                    )}
                    name="productCategoryId"
                    control={control}
                  />
                  <div className="text-danger">
                    {errors?.productCategoryId?.message}
                  </div>
                </div>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="startTime">Product Brand</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        data={
                          brandData
                            ? brandData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.brandName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Brand"
                      />
                    )}
                    name="brandId"
                    control={control}
                  />
                </div>
              </>
            )}
            {navigateTo == 2 && (
              <>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Shop Category</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomEnd"
                        data={
                          shopCategoryData
                            ? shopCategoryData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.categoryName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Shop Category"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="shopCategoryId"
                    control={control}
                  />
                  <div className="text-danger">
                    {errors?.shopCategoryId?.message}
                  </div>
                </div>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Select Shop</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomEnd"
                        data={
                          shopsData
                            ? shopsData.map((item) => {
                                return {
                                  value: item.id,
                                  label: `${item.shopNumber} - ${item.shopName}`,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Shop"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="shopId"
                    control={control}
                  />
                  <div className="text-danger">{errors?.shopId?.message}</div>
                </div>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Product</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        data={
                          productData
                            ? productData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.productName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Product"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="productId"
                    control={control}
                  />
                  <div className="text-danger">
                    {errors?.productId?.message}
                  </div>
                </div>
              </>
            )}
            {navigateTo == 3 && (
              <>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Shop Category</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomEnd"
                        data={
                          shopCategoryData
                            ? shopCategoryData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.categoryName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Shop Category"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="shopCategoryId"
                    control={control}
                  />
                  <div className="text-danger">
                    {errors?.shopCategoryId?.message}
                  </div>
                </div>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Select Shop</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomEnd"
                        data={
                          shopsData
                            ? shopsData.map((item) => {
                                return {
                                  value: item.id,
                                  label: `${item.shopNumber} - ${item.shopName}`,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Shop"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="shopId"
                    control={control}
                  />
                  <div className="text-danger">{errors?.shopId?.message}</div>
                </div>
              </>
            )}
            {navigateTo == 4 && (
              <>
                <div className="col-md-6 form-group my-1">
                  <label htmlFor="section">Shop Category</label>
                  <Controller
                    render={({ field: { ref, ...field } }) => (
                      <SelectPicker
                        placement="bottomEnd"
                        data={
                          shopCategoryData
                            ? shopCategoryData.map((item) => {
                                return {
                                  value: item.id,
                                  label: item.categoryName,
                                };
                              })
                            : []
                        }
                        {...field}
                        style={{ width: "100%" }}
                        placeholder="Select Shop Category"
                      />
                    )}
                    rules={{
                      required: "Thid field is required",
                    }}
                    name="shopCategoryId"
                    control={control}
                  />
                  <div className="text-danger">
                    {errors?.shopCategoryId?.message}
                  </div>
                </div>
              </>
            )}
            <div className="col-md-12 d-flex justify-content-center align-items-center pt-3 px-5">
              <button
                type="button"
                onClick={() => reset()}
                className="btn btn-warning mx-3"
              >
                Reset
              </button>
              {addSliderLoading ? (
                <button type="button" className="btn btn-success">
                  Submiting...
                </button>
              ) : (
                <button type="submit" className="btn btn-success">
                  Submit
                </button>
              )}
            </div>
          </div>
        </form>
      </Modal.Body>
    </Modal>
  );
};

export default AddHomeSlider;
