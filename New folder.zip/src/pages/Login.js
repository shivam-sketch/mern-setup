import { useMutation } from "@tanstack/react-query";
import React, { useState } from "react";
import api, { imageUrl } from "lib/api";
import { useAuth } from "../hooks/useAuth";
import { useForm } from "react-hook-form";

const Login = () => {
  const { login } = useAuth();
  const [serverError, setServerError] = useState({});
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    control,
    watch,
    setValue,
  } = useForm();

  const { mutate, isLoading } = useMutation(
    ["login"],
    (data) => api.post("login", data),
    {
      onSuccess: (res) => {
        if (res.data.status === "success") {
          login(res.data.data);
        } else {
          console.log(res.data);
          setServerError(res.data.message);
        }
      },
      onError: (err) => {
        console.log(err.messages);
      },
    }
  );

  const onSubmit = (data) => {
    mutate(data);
  };

  console.log("errors ", errors);

  return (
    <div className="loginContainer vw-100 vh-100 d-flex justify-content-center align-items-center">
      <div className="loginDiv w-25 shadow rounded p-4">
        <div className="text-center text-dark">
          <h4>Super Admin Login</h4>
        </div>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-group py-2">
            <label htmlFor="username" className="text-white h6">
              Username
            </label>
            <input
              {...register("username", { required: "This fiels is required." })}
              name="username"
              type="text"
              className="form-control"
              placeholder="Enter username"
              required
            />
            <span className="text-danger fw-bolder mt-2">
              {errors?.username?.message}
            </span>
          </div>
          <div className="form-group">
            <label htmlFor="password" className="text-white h6">
              Password
            </label>
            <input
              {...register("password", { required: "This fiels is required." })}
              name="password"
              type="text"
              className="form-control"
              placeholder="Enter Password"
            />
            <span className="text-danger fw-bolder mt-2">
              {errors?.password?.message}
            </span>
          </div>
          {/* <span className="text-danger">{serverError}</span> */}
          <div className="form-group">
            {isLoading ? (
              <button className="btn btn-danger w-100 my-4">
                please wait...
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="btn btn-danger w-100 my-4"
              >
                Login
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
