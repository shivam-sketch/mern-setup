import React from "react";
import { FiUsers } from "react-icons/fi";
import { BsShop } from "react-icons/bs";
import { FcShop } from "react-icons/fc";
import { FaUserTag } from "react-icons/fa";
import BarChart from "../components/dashboard/BarChart";
import LineChart from "../components/dashboard/LineChart";
import AreaChart from "../components/dashboard/AreaChart";
import Card from "../components/dashboard/Card";

const Dashboard = () => {
  return (
    <div className="row">
      <div className="col-md-8">
        <div className="row">
          <div className="col-md-3 col-sm-6 p-2">
            <Card title={"Total Users"} icon={<FiUsers />} />
          </div>
          <div className="col-md-3 col-sm-6 p-2">
            <Card title={"Total Registerd Shops"} icon={<BsShop />} />
          </div>
          <div className="col-md-3 col-sm-6 p-2">
            <Card title={"Total Wholesale Shop"} icon={<FcShop />} />
          </div>
          <div className="col-md-3 col-sm-6 p-2">
            <Card title={"Total Service Partner"} icon={<FaUserTag />} />
          </div>
          <div className="col-md-6 col-sm-12 p-2">
            <div className="p-2 bg-white shadow-sm rounded">
              <BarChart />
            </div>
          </div>
          <div className="col-md-6 col-sm-12 p-2">
            <div className="p-2 bg-white shadow-sm rounded">
              <LineChart />
            </div>
          </div>
          <div className="col-md-6 col-sm-12 p-2">
            <div className="p-2 bg-white shadow-sm rounded">
              <AreaChart />
            </div>
          </div>
          <div className="col-md-6 col-sm-12 p-2">
            <div className="p-2 bg-white shadow-sm rounded">
              <BarChart />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
