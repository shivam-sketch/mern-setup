import React from "react";

const Card = ({ title, icon }) => {
  return (
    <div className="shadow-sm rounded bg-white p-3">
      <div
        className="row d-flex justify-content-center align-items-center"
        style={{ fontSize: "2rem" }}
      >
        <div className="col-md-4">{icon}</div>
        <div className="col-md-8">54554</div>
      </div>
    </div>
  );
};

export default Card;
