import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import {
  Container,
  Header,
  Sidebar,
  Sidenav,
  Content,
  Nav,
  Dropdown,
} from "rsuite";
import { nav } from "../data/nav";
import { HiUserCircle } from "react-icons/hi";
import AppContent from "./AppContent";
import { AiOutlineBars } from "react-icons/ai";
import { FaArrowLeft } from "react-icons/fa";

const ProtectedLayout = () => {
  const navigate = useNavigate();
  const [expand, setExpand] = useState(false);
  const [mobile, setMobile] = useState(false);
  const { user, logout } = useAuth();
  const location = useLocation();
  const pathname = location.pathname;

  const handleResize = () => {
    if (window.innerWidth < 920) {
      setMobile(true);
    } else {
      setMobile(false);
    }
  };
  // create an event listener
  useEffect(() => {
    if (window.innerWidth < 920) {
      setMobile(true);
    }
    window.addEventListener("resize", handleResize);
  }, []);

  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <Container>
      <Sidebar
        style={{ display: "flex", flexDirection: "column" }}
        width={expand ? 260 : mobile ? 0 : 56}
        collapsible
        onMouseOver={() => {
          setExpand(true);
        }}
        onMouseOut={() => {
          setExpand(false);
        }}
      >
        <Sidenav expanded={expand} appearance="subtle">
          <div className="d-flex w-100 justify-content-between align-items-center p-2">
            <img
              src={expand ? "/images/logo.png" : "/images/minilogo.png"}
              width={expand ? 150 : 40}
            ></img>
            <FaArrowLeft
              size={30}
              onClick={() => setExpand(false)}
              className="sideToggle"
            />
          </div>
          <Sidenav.Body>
            <Nav>
              {nav.map((item, i) => {
                if (item.menu) {
                  return (
                    <Nav.Menu
                      key={i}
                      eventKey={i + 1}
                      trigger="click"
                      title={item.title}
                      icon={item.icon}
                      placement="rightStart"
                    >
                      {item.menu.map((item2, j) => {
                        return (
                          <Nav.Item
                            key={j}
                            eventKey="3-1"
                            onClick={() => {
                              navigate(item2.link);
                              setExpand(false);
                            }}
                          >
                            {item2.title}
                          </Nav.Item>
                        );
                      })}
                    </Nav.Menu>
                  );
                } else {
                  return (
                    <Nav.Item
                      key={i}
                      eventKey="2"
                      icon={item.icon}
                      onClick={() => {
                        navigate(item.link);
                        setExpand(false);
                      }}
                    >
                      {item.title}
                    </Nav.Item>
                  );
                }
              })}
            </Nav>
          </Sidenav.Body>
        </Sidenav>
      </Sidebar>

      <Container>
        <Header>
          <AiOutlineBars
            size={30}
            onClick={() => setExpand(true)}
            className="sideToggle"
          />
          <h4>{pathname.split("/")[1].replaceAll("-", " ")}</h4>
          <Dropdown
            trigger={["hover"]}
            title={<HiUserCircle />}
            placement="bottomEnd"
          >
            <Dropdown.Item>Profile</Dropdown.Item>
            <Dropdown.Item onClick={logout}>Logout</Dropdown.Item>
          </Dropdown>
        </Header>
        <Content className="p-2">
          <AppContent />
        </Content>
      </Container>
    </Container>
  );
};

export default React.memo(ProtectedLayout);
