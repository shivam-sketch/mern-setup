import api from '../lib/api';
import { useAuth } from './useAuth';


const useRefreshToken = () => {
    const { setAuth } = useAuth();

    const refresh = async () => {
        const response = await api.post('/auth/refresh', {
            withCredentials: true
        });

        // console.log('refresh', response.data.data)
        setAuth(prev => {
            console.log(JSON.stringify(prev));
            return { ...prev, token: response.data.data.token }
        });
        return response.data.data.token;
    }
    return refresh;
};

export default useRefreshToken;