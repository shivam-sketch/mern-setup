/* eslint-disable @typescript-eslint/no-var-requires */
export const { default: Error404Img } = require('./404.svg');
export const { default: Error500Img } = require('./500.svg');
export const { default: Error503Img } = require('./503.svg');
export const { default: Error403Img } = require('./403.svg');
