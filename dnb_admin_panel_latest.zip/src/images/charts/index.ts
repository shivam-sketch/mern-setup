/* eslint-disable @typescript-eslint/no-var-requires */
export const { default: PVIcon } = require('./pv.svg');
export const { default: UVIcon } = require('./uv.svg');
export const { default: VVICon } = require('./vv.svg');
