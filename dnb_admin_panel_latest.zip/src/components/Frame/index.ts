import Frame from './Frame';
export default Frame;
