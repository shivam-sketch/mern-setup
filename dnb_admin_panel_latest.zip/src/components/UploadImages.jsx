import { useMutation } from '@tanstack/react-query';
import cogoToast from 'cogo-toast';
import React from 'react'
import Dropzone from 'react-dropzone'

const UploadImages = () => {


    const { mutate: uploadImages } = useMutation({
        mutationFn: (data) => {
          const headers = {
            headers: { 'Content-Type': 'multipart/form-data' },
          }
    
          return axiosPrivate.post("/web/upload-images", data, headers)
        },
    
    
        onError: (data, error, variables, context) => {
          // An error happened!
    
          if (data.response.data.message) {
    
            cogoToast.error(`${data.response.data.message}`);
          } else {
            cogoToast.error(`server error`);
    
          }
    
        },
        onSuccess: (data, variables, context) => {
          if (data.data.status == 200) {
    
            let tempurls = [...imagesUrl, ...data?.data?.data?.name]
            setImagesUrl(tempurls)
            setImages([])
            cogoToast.success('Images Uploaded')
            setIsUploaded(true)
          }
        },
    
      });

    const onImagesUpload = (files) => {
        // console.log(files)
    
        let tempImages = { ...images, ...files }
        setImages([...tempImages])
    
    
      }


    const handleImagesSubmit = () => {
        if (images?.length == 0) {
            cogoToast.error('images not selected')
            return
        }

        const fd = new FormData()
        images?.forEach((item) => {
            console.log(item)
            fd.append('image', item[0])

        })

        uploadImages(fd)


    }






    return (
        <>
            <Dropzone onDrop={onImagesUpload}>
                {({ getRootProps, getInputProps }) => (
                    <section>
                        <div {...getRootProps()} style={{ border: '2px solid #3c3f43', height: 100 }}>
                            <input {...getInputProps()} />
                            <p>Drag 'n' drop some images here, or click to select images</p>

                            {images?.length > 0 ? (
                                <>
                                    {
                                        images?.map((item, index) => {
                                            return (
                                                <img src={`${URL.createObjectURL(item[0])}`} width={50} />

                                            )
                                        })
                                    }

                                </>

                            ) : (<></>)}
                        </div>
                    </section>
                )}
            </Dropzone>
            <div className="row">

                <Button appearance='primary' onClick={handleImagesSubmit} >
                    Start Uploading


                </Button>
            </div>

        </>
    )
}

export default UploadImages