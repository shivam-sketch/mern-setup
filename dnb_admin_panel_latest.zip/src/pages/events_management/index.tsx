import React from 'react';
import { Breadcrumb, Panel } from 'rsuite';
import DataTable from './DataTable';
// import './styles.less'
const Page = () => {
  return (
    <Panel
      header={
        <>
          <h3 className="title">Events</h3>
          <Breadcrumb>
            <Breadcrumb.Item href="/">Events</Breadcrumb.Item>
          </Breadcrumb>
        </>
      }
    >
      <DataTable />
    </Panel>
  );
};

export default Page;
