import React from 'react';
import { Breadcrumb, Panel } from 'rsuite';
import TermsAndCondition from './TermsAndConditions';

const Page = () => {
  return (
    <Panel
      header={
        <>
          <h3 className="title">Static</h3>
          <Breadcrumb>
            <Breadcrumb.Item href="/">Static</Breadcrumb.Item>
            <Breadcrumb.Item active>TermsAndCondition</Breadcrumb.Item>
          </Breadcrumb>
        </>
      }
    >
      <TermsAndCondition />
    </Panel>
  );
};

export default Page;
