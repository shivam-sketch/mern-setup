import React, { useEffect, useRef, useState } from 'react'
import JoditEditor from "jodit-react";
import { useMutation, useQuery } from '@tanstack/react-query';
import useAxiosPrivate from '@/hooks/useAxiosPrivate';
import cogoToast from 'cogo-toast';
import { Button } from 'rsuite';



const TermsAndCondition = () => {

    const [content, setContent] = useState("");
    const editor = useRef(null);
    const joditTheme = 'dark';

    const axiosPrivate = useAxiosPrivate()
    // const { mutate, isLoading } = useMutation({
    //     mutationFn: (data) => axiosPrivate.post("/web/privacy-policy", data),

    //     onError: (error, variables, context) => {
    //         // An error happened!
    //     },
    //     onSuccess: (data, variables, context) => {
    //         console.log(data.data)
    //         if (data.data.status == 200) {
    //             let htmlData = data.data.data.replace(/(<([^>]+)>)/gi, "").replace(/&nbsp;/g, " ")
    //             setContent(htmlData);
    //         }
    //     },
    // });

    const { data: terms_and_condition, refetch } = useQuery({
        queryKey: ["terms-and-conditions"],
        queryFn: () => axiosPrivate.get(`web/terms-and-conditions`),
        select: (res) => res?.data?.data,
    });




    const { mutate } = useMutation({
        mutationFn: (data) => axiosPrivate.post("/web/add-terms-and-conditions", data),


        onError: (data, error, variables, context) => {
            // An error happened!

            if (data.response.data.message) {

                cogoToast.error(`${data.response.data.message}`);
            } else {
                cogoToast.error(`server error`);

            }

        },
        onSuccess: (data, variables, context) => {
            if (data.data.status == 201) {
                cogoToast.success('updated')
                refetch()
            }
        },

    });




    useEffect(() => {
        if (terms_and_condition?.terms_and_condition) {

            let htmlData = terms_and_condition?.terms_and_condition?.replace(/(<([^>]+)>)/gi, "").replace(/&nbsp;/g, " ")
            setContent(htmlData);
        }


    }, [terms_and_condition])




    return (
        <div>

            <JoditEditor
                ref={editor}
                value={content}
                onBlur={(newContent) => setContent(newContent)}
                onChange={(newContent) => { }}
                config={{
                    theme: joditTheme,

                }}
                style={{ color: "black" }}
            />
            <Button appearance='primary' onClick={() => {
                mutate({ content })
            }}>
                Submit
            </Button>


        </div>
    )
}

export default TermsAndCondition