import React from 'react';
import { Breadcrumb, Panel } from 'rsuite';
import AboutUs from './AboutUs';
import './styles.less'

const Page = () => {
  return (
    <Panel
      header={
        <>
          <h3 className="title">Static</h3>
          <Breadcrumb>
            <Breadcrumb.Item href="/">Static</Breadcrumb.Item>
            <Breadcrumb.Item active>About us</Breadcrumb.Item>
          </Breadcrumb>
        </>
      }
    >
      <AboutUs />
    </Panel>
  );
};

export default Page;
