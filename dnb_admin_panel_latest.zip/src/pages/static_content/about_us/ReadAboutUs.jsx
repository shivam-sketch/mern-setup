import api from '@/lib/api';
import { useQuery } from '@tanstack/react-query';
import React from 'react'

const ReadAboutUs = () => {


    const { data: getAboutUs, refetch } = useQuery({
        queryKey: ["about-us"],
        queryFn: () => api.get("web/about-us"),
        select: (res) => res.data.data[0]?.about,
    });
    return (
        <div>

            {
                getAboutUs
            }


        </div>
    )
}

export default ReadAboutUs