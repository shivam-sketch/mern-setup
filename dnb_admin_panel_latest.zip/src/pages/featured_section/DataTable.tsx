import React, { useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Stack,
  Form,
  CheckboxGroup,
  CheckPicker,
} from "rsuite";

import { useMutation, useQuery } from "@tanstack/react-query";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";

import { Controller, useForm } from "react-hook-form";
import cogoToast from "cogo-toast";


const DataTable = () => {
  const axiosPrivate = useAxiosPrivate();
  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    watch
  } = useForm({
    defaultValues: {
      selectType: [],
      featuredEvents: [],
      featuredMusics: [],
      featuredVideos: []
    },
  })








  const { data: features, refetch, isLoading } = useQuery({
    queryKey: ["get-featured-content"],
    queryFn: () => axiosPrivate.get(`web/get-featured-content`),
    select: (res) => res.data.data,
    enabled: true
  });

  const selectType = watch('selectType')


  useEffect(() => {
    if (features) {

      setValue('selectType', features?.selectType)
      setValue('featuredMusics', features?.featuredMusics)
      setValue('featuredEvents', features?.featuredEvents)
      setValue('featuredVideos', features?.featuredVideos)


    }



  }, [features])






  const { data: musics } = useQuery({
    queryKey: ["get-musics"],
    queryFn: () => axiosPrivate.get(`web/get-musics`),
    select: (res) => res?.data?.data?.result,
  });



  const { data: events } = useQuery({
    queryKey: ["get-events"],
    queryFn: () => axiosPrivate.get(`web/get-events`),
    select: (res) => res?.data?.data,
  });

  const { data: videos } = useQuery({
    queryKey: ["get-videos"],
    queryFn: () => axiosPrivate.get(`web/get-videos`),
    select: (res) => res?.data?.data,
  });


  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/add-featured-content", data),


    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {

        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);

      }

    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 201) {
        reset()
        cogoToast.success('added')
        refetch()
      }
    },

  });












  const onSubmit = (data) => {
    let body = {
      selectType: data.selectType,
      featuredId: features?._id
    }
    if (data.selectType?.includes('Event')) {
      if (data?.featuredEvents?.length > 0) {
        body['featuredEvents'] = data.featuredEvents
      } else {
        cogoToast.error('no event selected!')
      }

    }

    if (data.selectType?.includes('Music')) {
      if (data?.featuredMusics?.length > 0) {
        body['featuredMusics'] = data.featuredMusics
      } else {
        cogoToast.error('no music selected!')
      }

    }

    if (data.selectType?.includes('Video')) {
      if (data?.featuredVideos?.length > 0) {
        body['featuredVideos'] = data.featuredVideos
      } else {
        cogoToast.error('no video uploaded!')
      }
    }

    console.log(body)



    mutate(body)
  }

  console.log(events)
  return (
    <>
      <Form fluid onSubmit={handleSubmit(onSubmit)} >
        <Stack justifyContent="space-between" style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 15 }}>

          {/* <CheckboxGroup inline name="checkboxList" value={value} onChange={handleChange}> */}

          <Form.Group>
            <Form.ControlLabel>Select Type</Form.ControlLabel>

            <Controller
              control={control}
              rules={{
                // required: 'this field is required'
              }}
              render={({ field }) => (
                <CheckboxGroup
                  inline
                  name="checkboxList"
                  {...field}
                >
                  <Checkbox {...field} value={"Music"}>
                    Music
                  </Checkbox>
                  <Checkbox {...field} value={"Event"}>
                    Event
                  </Checkbox>
                  <Checkbox value={"Video"}>
                    Video
                  </Checkbox>
                </CheckboxGroup>
              )}
              name="selectType"
            />


          </Form.Group>





          {/* </CheckboxGroup> */}

        </Stack>
        <div className="row">
          <div className="col-md-4">

            {
              selectType?.includes('Music') ? <Form.Group>
                <Form.ControlLabel>Musics</Form.ControlLabel>

                <Controller
                  control={control}
                  rules={{
                    // required: 'this field is required'
                  }}
                  render={({ field }) => (


                    <CheckPicker data={musics?.map((item) => {
                      return {
                        label: item?.title, value: item._id
                      }
                    })} style={{ width: '100%' }}   {...field} />


                  )}
                  name="featuredMusics"
                />

                {errors.featuredMusics && <p style={{ color: 'red' }} role="alert">{errors.featuredMusics.message}</p>}

              </Form.Group> : <></>


            }
          </div>
          <div className="col-md-4">



            {
              selectType?.includes('Event') ? <> <Form.Group>
                <Form.ControlLabel>Future events</Form.ControlLabel>

                <Controller
                  control={control}
                  rules={{
                    // required: 'this field is required'
                  }}
                  render={({ field }) => (


                    <CheckPicker data={events?.futureEvents?.map((item) => {
                      return {
                        label: item?.eventName, value: item._id
                      }
                    })} style={{ width: '100%' }}  {...field} />


                  )}
                  name="featuredEvents"
                />

                {errors.featuredEvents && <p style={{ color: 'red' }} role="alert">{errors.featuredEvents.message}</p>}

              </Form.Group>


                <Form.Group>
                  <Form.ControlLabel>Past Events</Form.ControlLabel>

                  <Controller
                    control={control}
                    rules={{
                      // required: 'this field is required'
                    }}
                    render={({ field }) => (


                      <CheckPicker data={events?.pastEvents?.map((item) => {
                        return {
                          label: item?.eventName, value: item._id
                        }
                      })} style={{ width: '100%' }} {...field} />


                    )}
                    name="featuredEvents"
                  />

                  {errors.featuredEvents && <p style={{ color: 'red' }} role="alert">{errors.featuredEvents.message}</p>}

                </Form.Group>












              </> : <></>


            }
          </div>
          <div className="col-md-4">


            {
              selectType?.includes('Video') ?
                <Form.Group>
                  <Form.ControlLabel>videos</Form.ControlLabel>

                  <Controller
                    control={control}
                    rules={{
                      // required: 'this field is required'
                    }}
                    render={({ field }) => (


                      <CheckPicker data={videos?.map((item) => {
                        return {
                          label: item?.name, value: item._id
                        }
                      })} style={{ width: '100%' }} {...field} />


                    )}
                    name="featuredVideos"
                  />

                  {errors.featuredVideos && <p style={{ color: 'red' }} role="alert">{errors.featuredVideos.message}</p>}

                </Form.Group> : <></>


            }

          </div>









        </div>







        <Button type='submit' appearance="primary">
          Submit
        </Button>
      </Form>
    </>
  );
};

export default DataTable;
