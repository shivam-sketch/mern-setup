import React, { useEffect, useState } from "react";
import {
  Input,
  InputGroup,
  Table,
  Button,
  DOMHelper,
  Progress,
  Checkbox,
  Stack,
  SelectPicker,
  Pagination,
  Modal,
  Whisper,
} from "rsuite";
import SearchIcon from "@rsuite/icons/Search";
import CloseOutlineIcon from '@rsuite/icons/CloseOutline';
import AttachmentIcon from '@rsuite/icons/Attachment';
import SendIcon from '@rsuite/icons/Send';
import MoreIcon from "@rsuite/icons/legacy/More";
import DrawerView from "./DrawerView";
import { mockUsers } from "@/data/mock";
import { NameCell, ImageCell, CheckCell, ActionCell } from "./Cells";
import { useMutation, useQuery } from "@tanstack/react-query";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import EditDrawerView from "./EditDrawerView";
import DelteModal from "."
import DeleteModal from "./DeleteRow";
import dayjs from "dayjs";
import { useLocation, useSearchParams } from "react-router-dom";
import cogoToast from "cogo-toast";
const { Column, HeaderCell, Cell } = Table;
const { getHeight } = DOMHelper;
import { io } from 'socket.io-client';
import { socketEndPoint } from "@/lib/api";
var socket;
const DataTable = (props) => {
  const [showDrawer, setShowDrawer] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [checkedKeys, setCheckedKeys] = useState<number[]>([]);
  const [sortColumn, setSortColumn] = useState();
  const [sortType, setSortType] = useState();
  const [searchKeyword, setSearchKeyword] = useState("");
  const [editData, setEditData] = useState({});
  const [data, setData] = useState([]);

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(100);
  const [total, setTotal] = useState(0);

  const [description, setDescription] = useState("");
  const [imagesUrl, setImagesUrl] = useState([])
  const axiosPrivate = useAxiosPrivate();
  const [search] = useSearchParams()
  const roomId = search.get('roomId')
  const { data: adminChats, isLoading, refetch } = useQuery({
    queryKey: ["get-admin-chats", roomId],
    queryFn: () => axiosPrivate.get(`chat/get-admin-chats?page=${page}&limit=${limit}&roomId=${roomId}`),
    select: (res) => res?.data?.data,
    enabled: false
  });


  const { mutate: uploadImages } = useMutation({
    mutationFn: (data) => {
      const headers = {
        headers: { "Content-Type": "multipart/form-data" },
      };

      return axiosPrivate.post("/web/upload-images", data, headers);
    },

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        let tempurls = [...imagesUrl, ...data?.data?.data?.name];
        setImagesUrl(tempurls);
        // cogoToast.success("Images Uploaded");
        let body = {
          chatName: "DNB AllStars Hotline", description, roomId, image: tempurls[0]
        }
        mutate(body)
      }
    },
  });


  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/chat/add-admin-chat", data),


    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {

        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);

      }

    },
    onSuccess: (data, variables, context) => {
      console.log(data.data)
      if (data.data.status == 201) {
        // cogoToast.success('Admin Chat Added')
        socket.emit("new_admin_chat", data.data.data);
        setImagesUrl([])
        refetch()
        setDescription("")
        setSelectedFile(null)
      }
    },

  });


  useEffect(() => {
    window.scrollTo(0, document.body.scrollHeight);
  }, [data])

  useEffect(() => {
    socket = io(socketEndPoint);
    socket.on("connect", () => {
      console.log(socket.id); // x8WIv7-mJelg7on_ALbx
    });
    // socket.on("get_admin_chat", (data) => {
    //   console.log('get_admin_chat', data);
    // });

    console.log('socket', socket)
    // socket.emit("join_room", "65ab7cf37777282fc065f1f6");





  }, [])


  useEffect(() => {

    if (adminChats?.result?.length > 0) {
      setData(adminChats.result)
      setTotal(adminChats.paginate?.totalResults)

    } else {
      setData([])
      setTotal(0)

    }


  }, [adminChats])



  useEffect(() => {
    refetch()
  }, [showDrawer, page, limit, editOpen, deleteOpen, roomId]);

  let checked = false;
  let indeterminate = false;

  if (checkedKeys?.length === data?.length) {
    checked = true;
  } else if (checkedKeys?.length === 0) {
    checked = false;
  } else if (checkedKeys?.length > 0 && checkedKeys?.length < data?.length) {
    indeterminate = true;
  }

  const handleChangeLimit = (dataKey) => {
    setPage(1);
    setLimit(dataKey);
  };

  const handleCheckAll = (_value, checked) => {
    const keys = checked ? data.map((item) => item?._id) : [];
    setCheckedKeys(keys);
  };
  const handleCheck = (value, checked) => {
    const keys = checked
      ? [...checkedKeys, value]
      : checkedKeys.filter((item) => item !== value);
    setCheckedKeys(keys);
  };

  const handleSortColumn = (sortColumn, sortType) => {
    setSortColumn(sortColumn);
    setSortType(sortType);
  };

  const filteredData = () => {
    const filtered = data?.filter((item) => {
      if (!item?.chatName?.includes(searchKeyword)) {
        return false;
      }
      return true;
    })?.map((map_item) => { return { ...map_item, roomName: map_item?.roomDetails?.name, roomId: map_item?.roomDetails?._id } })
    if (sortColumn && sortType) {
      return filtered.sort((a, b) => {
        let x: any = a[sortColumn];
        let y: any = b[sortColumn];

        if (typeof x === "string") {
          x = x.charCodeAt(0);
        }
        if (typeof y === "string") {
          y = y.charCodeAt(0);
        }

        if (sortType === "asc") {
          return x - y;
        } else {
          return y - x;
        }
      });
    }
    return filtered;
  };

  console.log(data);



  const handleFileChange = (event, onClose) => {
    const file = event.target.files[0];
    setSelectedFile(file);
    onClose()

  }

  const handleImagesUpload = () => {
    if (selectedFile) {

      let fd = new FormData()
      fd.append('image', selectedFile)

      uploadImages(fd)

    } else {
      let body = {
        chatName: "DNB AllStars Hotline", description, roomId, image: "https://dnb-api.alcax.com/images/dummy_chat.jpg"
      }
      mutate(body)
    }




  }
  console.log('selecte file', selectedFile)


  const Overlay = React.forwardRef(({ style, onClose, ...rest }, ref) => {
    const styles = {
      ...style,
      color: '#fff',
      background: 'black',
      width: 200,
      padding: 10,
      zIndex: 99,
      borderRadius: 4,
      position: 'absolute',
      border: '1px solid #1a1d2400',
      boxShadow: '0 3px 6px -2px rgba(0, 0, 0, 0.6)'
    };

    return (
      <div {...rest} style={styles} ref={ref}>

        <label htmlFor="pinImage" style={{ width: 200 }}   >

          Attach
        </label>
        <input id="pinImage" hidden type="file" onChange={(event) => handleFileChange(event, onClose)} accept=".jpg,.jpeg,.png" />
      </div>
    );
  });







  return (
    <div className="container">



      {/* <Table
        height={Math.max(getHeight(window) - 200, 400)}
        data={filteredData()}
        sortColumn={sortColumn}
        sortType={sortType}
        onSortColumn={handleSortColumn}
        loading={isLoading}
      >
        

        <Column width={50} fixed>
          <HeaderCell style={{ padding: 0 }}>
            <div style={{ lineHeight: "40px" }}>
              <Checkbox
                inline
                checked={checked}
                indeterminate={indeterminate}
                onChange={handleCheckAll}
              />
            </div>
          </HeaderCell>
          <CheckCell
            dataKey="_id"
            checkedKeys={checkedKeys}
            onChange={handleCheck}
          />
        </Column>

        <Column width={300}>
          <HeaderCell>Image</HeaderCell>
          <ImageCell dataKey="image" />
        </Column>

        <Column width={300}>
          <HeaderCell>Room Name</HeaderCell>
          <Cell dataKey="roomName" />
        </Column>
        <Column width={300}>
          <HeaderCell>Chat Name</HeaderCell>
          <NameCell dataKey="chatName" />
        </Column>



        <Column width={120}>
          <HeaderCell>Action</HeaderCell>
          <ActionCell
            dataKey="id"
            editData={editData}
            setEditData={setEditData}
            editOpen={editOpen}
            setEditOpen={setEditOpen}
            deleteOpen={deleteOpen}
            setDeleteOpen={setDeleteOpen}
          />
        </Column>
      </Table> */}


      {
        data?.map((item) => {

          return (

            <div className="row">
              <div className="col-sm-8 mt-5">
                <div>
                  <img src={`${item?.image}`} width={100} height={100} />

                </div>

                <p>
                  {item?.description}
                </p>

              </div>
            </div>


          )


        })


      }




      <InputGroup style={{
        // width: 300,
        height: 150,
        marginBottom: 20,
        marginTop: 100
      }} size="lg" >
        <Input size="lg" style={{}} onChange={setDescription} value={description} />
        <InputGroup.Button style={{ top: 108, left: 44 }} onClick={handleImagesUpload} >
          <SendIcon />
        </InputGroup.Button>

        <InputGroup.Button style={{ top: 108, right: 1192 }}>


          <Whisper
            trigger="click"
            placement="top"
            speaker={(props, ref) => {
              const { className, left, top, onClose } = props;
              return <Overlay style={{ left, top }} onClose={onClose} className={className} ref={ref} />;
            }}
          >
            <AttachmentIcon />
          </Whisper>

        </InputGroup.Button>
      </InputGroup>


      <div style={{ padding: 20 }}>

        {
          selectedFile ? (<><label className="d-flex-end" onClick={() => {
            setSelectedFile(null)
          }}><CloseOutlineIcon /></label><div><img src={`${URL.createObjectURL(selectedFile)}`} width={100} height={100} /></div> </>) : <></>
        }
      </div>

      <DrawerView open={showDrawer} onClose={() => setShowDrawer(false)} />
      <EditDrawerView
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editData={editData}
        setEditData={setEditData}
      />
      <DeleteModal open={deleteOpen}
        handleClose={() => setDeleteOpen(false)} deleteType="chat" editData={editData} />
    </div>
  );
};

export default DataTable;
