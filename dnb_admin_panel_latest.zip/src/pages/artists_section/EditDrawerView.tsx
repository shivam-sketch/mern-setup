import ImageUploader from "@/components/ImageUploader";
import useAxiosPrivate from "@/hooks/useAxiosPrivate";
import { useCommon } from "@/hooks/useCommon";
import api from "@/lib/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import cogoToast from "cogo-toast";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import Dropzone from "react-dropzone";
import { Controller, useForm } from "react-hook-form";
import { FaClock } from "react-icons/fa";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker,
  DatePicker,
} from "rsuite";

const EditDrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const {
    images,
    setImages,
    imagesUrl,
    setImagesUrl,
    isUploaded,
    setIsUploaded,
  } = useCommon();

  const { onClose, editData, setEditData, setEditOpen, ...rest } = props;

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm({
    defaultValues: {},
  });

  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/edit-artists", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        cogoToast.success("Event Edited");
        setImagesUrl([]);

        onClose();
      }
    },
  });

  useEffect(() => {
    if (editData) {
      setValue("name", editData.name);
    }
  }, [editData]);

  const onSubmit = (data) => {
    let body = {
      ...data,
      id: editData._id,
    };
    if (imagesUrl?.length > 0) {
      body["image"] = imagesUrl[0];
    }

    mutate(body);
  };

  console.log(editData);

  return (
    <Drawer
      backdrop="static"
      size="sm"
      placement="right"
      onClose={onClose}
      {...rest}
    >
      <Drawer.Header>
        <Drawer.Title>Edit Artists</Drawer.Title>
        <Drawer.Actions>
          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)}>
          <Stack
            justifyContent="space-between"
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 7,
            }}
          >
            <Form.Group>
              <Form.ControlLabel>Artist Name</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: "this field is required",
                }}
                render={({ field }) => <Form.Control name="name" {...field} />}
                name="name"
              />

              {errors.name && (
                <p style={{ color: "red" }} role="alert">
                  {errors.name.message}
                </p>
              )}
            </Form.Group>
          </Stack>

          <Stack
            spacing={12}
            style={{
              marginBottom: 20,
              backgroundColor: "transparent",
              columnGap: 2,
            }}
          >
            <ImageUploader editData={editData} limit={1} />
          </Stack>

          <div className="row" style={{ marginTop: 10 }}>
            <Button type="submit" appearance="primary">
              Submit
            </Button>
          </div>
        </Form>
      </Drawer.Body>
    </Drawer>
  );
};

export default EditDrawerView;
