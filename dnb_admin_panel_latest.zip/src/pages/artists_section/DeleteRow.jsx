import useAxiosPrivate from '@/hooks/useAxiosPrivate';
import { useMutation } from '@tanstack/react-query';
import cogoToast from 'cogo-toast';
import React from 'react'
import { Button, Modal } from 'rsuite'
import RemindIcon from '@rsuite/icons/legacy/Remind';
const DeleteModal = ({ open, handleClose, deleteType, editData }) => {
    const axiosPrivate = useAxiosPrivate();

    const { mutate } = useMutation({
        mutationFn: (data) => axiosPrivate.post("/common/delete-data", data),


        onError: (data, error, variables, context) => {
            // An error happened!

            if (data.response.data.message) {

                cogoToast.error(`${data.response.data.message}`);
            } else {
                cogoToast.error(`server error`);

            }

        },
        onSuccess: (data, variables, context) => {
            if (data.data.status == 200) {
                cogoToast.success('user Deleted')
                handleClose()
            }
        },

    });

    console.log(open)


    return (
        <Modal backdrop="static" role="alertdialog" open={open} onClose={handleClose} size="xs">
            <Modal.Body>
                <RemindIcon style={{ color: '#ffb300', fontSize: 24 }} />
                Are You Sure you want to delete it ?
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={() => {
                    mutate({
                        id: editData._id,
                        deleteType
                    })
                }} appearance="primary">
                    Ok
                </Button>
                <Button onClick={handleClose} appearance="subtle">
                    Cancel
                </Button>
            </Modal.Footer>
        </Modal>
    )
}

export default DeleteModal