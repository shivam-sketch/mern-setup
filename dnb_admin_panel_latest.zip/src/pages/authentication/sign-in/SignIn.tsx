import React, { useState } from "react";
import { Form, Button, Panel, IconButton, Stack, Divider } from "rsuite";
import { Link } from "react-router-dom";
import GithubIcon from "@rsuite/icons/legacy/Github";
import FacebookIcon from "@rsuite/icons/legacy/Facebook";
import GoogleIcon from "@rsuite/icons/legacy/Google";
import WechatIcon from "@rsuite/icons/legacy/Wechat";
import Brand from "@/components/Brand";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import api from "../../../lib/api";
import cogoToast from "cogo-toast";
const SignUp = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { mutate } = useMutation({
    mutationFn: (data) => api.post("/auth/login", data),

    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {
        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);
      }
    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 200) {
        login(data.data.data);
      }
    },
  });

  console.log(email);
  const onSubmit = () => {
    if (
      password.length < 8 ||
      !/[A-Z]/.test(password) ||
      !/[a-z]/.test(password) ||
      !/[!@#$%^&*()\-=_+{};':",.<>/?[\]\\|]/.test(password)
    ) {
      cogoToast.error(
        "Password must include atleast one lowercase letter, one uppercase letter, one number and one special character and must be atleast 8 characters long"
      );
      return;
    }

    let body = { email: email, password: password };
    mutate(body);
  };

  return (
    <Stack
      justifyContent="center"
      alignItems="center"
      direction="column"
      style={{
        height: "100vh",
      }}
    >
      <Brand style={{ marginBottom: 10 }} />

      <Panel
        bordered
        style={{ background: "#fff", width: 400 }}
        header={<h3>Sign In</h3>}
      >
        {/* <p style={{ marginBottom: 10 }}>
          <span className="text-muted">New Here? </span>{' '}
          <Link to="/sign-up"> Create an Account</Link>
        </p> */}

        <Form fluid>
          <Form.Group>
            <Form.ControlLabel>Username or email address</Form.ControlLabel>
            <Form.Control
              name="email"
              type="email"
              onChange={(val) => {
                setEmail(val);
              }}
            />
          </Form.Group>
          <Form.Group>
            <Form.ControlLabel>
              <span>Password</span>
              {/* <a style={{ float: 'right' }}>Forgot password?</a> */}
            </Form.ControlLabel>
            <Form.Control
              name="name"
              type="password"
              onChange={(val) => {
                setPassword(val);
              }}
            />
          </Form.Group>
          <Form.Group>
            <Stack spacing={6} divider={<Divider vertical />}>
              <Button appearance="primary" onClick={onSubmit}>
                Sign in
              </Button>
              <Stack spacing={6}>
                <IconButton icon={<WechatIcon />} appearance="subtle" />
                <IconButton icon={<GithubIcon />} appearance="subtle" />
                <IconButton icon={<FacebookIcon />} appearance="subtle" />
                <IconButton icon={<GoogleIcon />} appearance="subtle" />
              </Stack>
            </Stack>
          </Form.Group>
        </Form>
      </Panel>
    </Stack>
  );
};

export default SignUp;
