
import useAxiosPrivate from '@/hooks/useAxiosPrivate';
import api from '@/lib/api';
import { useMutation, useQuery } from '@tanstack/react-query';
import cogoToast from 'cogo-toast';
import React, { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css'

import {
  Drawer,
  DrawerProps,
  Button,
  Form,
  Stack,
  InputNumber,
  InputGroup,
  Slider,
  Rate,
  CheckPicker,
  SelectPicker
} from 'rsuite';

const DrawerView = (props: DrawerProps) => {
  const axiosPrivate = useAxiosPrivate();
  const [code, setCode] = useState('')
  const [phone, setPhone] = useState('')
  const [flag, setFlag] = useState('')
  const { onClose, ...rest } = props;
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm({
    defaultValues: {

    },
  })
  const { mutate } = useMutation({
    mutationFn: (data) => axiosPrivate.post("/web/add-privacy-policy", data),


    onError: (data, error, variables, context) => {
      // An error happened!

      if (data.response.data.message) {

        cogoToast.error(`${data.response.data.message}`);
      } else {
        cogoToast.error(`server error`);

      }

    },
    onSuccess: (data, variables, context) => {
      if (data.data.status == 201) {
        reset()
        cogoToast.success('added')
        onClose()
      }
    },

  });







  const onSubmit = (data) => {


    mutate(data)
  }



  return (
    <Drawer backdrop="static" size="sm" placement="right" onClose={onClose} {...rest}>
      <Drawer.Header>
        <Drawer.Title>Add</Drawer.Title>
        <Drawer.Actions>
          <Button onClick={onClose} appearance="subtle">
            Cancel
          </Button>
        </Drawer.Actions>
      </Drawer.Header>

      <Drawer.Body>
        <Form fluid onSubmit={handleSubmit(onSubmit)} >
          <Stack justifyContent="space-between" style={{ marginBottom: 20, backgroundColor: 'transparent', columnGap: 15 }}>
            <Form.Group>
              <Form.ControlLabel>Title</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: 'this field is required'

                }}
                render={({ field }) => (

                  <Form.Control name="title" {...field} />
                )}
                name="title"
              />

              {errors.title && <p style={{ color: 'red' }} role="alert">{errors.title.message}</p>}


            </Form.Group>
            <Form.Group>
              <Form.ControlLabel>Description</Form.ControlLabel>

              <Controller
                control={control}
                rules={{
                  required: 'this field is required'

                }}
                render={({ field }) => (

                  <Form.Control name="description" {...field} />
                )}
                name="description"
              />

              {errors.description && <p style={{ color: 'red' }} role="alert">{errors.description.message}</p>}


            </Form.Group>
          </Stack>

          <Button type='submit' appearance="primary">
            Submit
          </Button>
        </Form>
      </Drawer.Body>
    </Drawer>
  );
};

export default DrawerView;
