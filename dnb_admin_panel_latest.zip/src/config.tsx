import React from "react";
import { Icon } from "@rsuite/icons";
import { VscTable, VscCalendar } from "react-icons/vsc";
import { MdFingerprint, MdDashboard, MdModeEditOutline } from "react-icons/md";
import CubesIcon from "@rsuite/icons/legacy/Cubes";

export const appNavs = [
  {
    eventKey: "Users",
    icon: <Icon as={VscTable} />,
    title: "Users Management",
    to: "/users",
  },
  {
    eventKey: "Events",
    icon: <Icon as={VscTable} />,
    title: "Events Management",
    to: "/events",
  },
  // {
  //   eventKey: 'dashboard',
  //   icon: <Icon as={MdDashboard} />,
  //   title: 'Dashboard',
  //   to: '/dashboard'
  // },
  {
    eventKey: "Chat_Section",
    icon: <Icon as={VscTable} />,
    title: "Chat Management",
    to: "/chat-rooms",
    // children: [
    //   {
    //     eventKey: 'chat_room',
    //     title: 'Chat Room',
    //     to: '/chat-rooms'
    //   },
    //   {
    //     eventKey: 'admin_chat',
    //     title: 'Admin Chat',
    //     to: '/admin-chat'
    //   },

    // ]
  },
  {
    eventKey: "Artists",
    icon: <Icon as={VscTable} />,
    title: "Artists Management",
    to: "/artists",
  },
  {
    eventKey: "Musics",
    icon: <Icon as={VscTable} />,
    title: "Musics Management",
    to: "/musics",
  },
  {
    eventKey: "featured",
    icon: <Icon as={VscTable} />,
    title: "Featured Content",
    to: "/add-featured",
  },

  {
    eventKey: "static",
    icon: <Icon as={VscTable} />,
    title: "Static Section",
    to: "/table-members",
    children: [
      {
        eventKey: "privacy-policy",
        title: "Privacy Policy",
        to: "/add-privacy-policy",
      },
      {
        eventKey: "terms-and-condition",
        title: "Terms And Conditions",
        to: "/add-terms-and-conditions",
      },
      {
        eventKey: "about-us",
        title: "About Us",
        to: "/add-about-us",
      },
      {
        eventKey: "Help",
        icon: <Icon as={VscTable} />,
        title: "Help",
        to: "/help",
      },
    ],
  },

  // {
  //   eventKey: 'authentication',
  //   title: 'Authentication',
  //   icon: <Icon as={MdFingerprint} />,
  //   children: [
  //     {
  //       eventKey: 'sign-in',
  //       title: 'Sign In',
  //       to: '/sign-in'
  //     },

  //     {
  //       eventKey: 'sign-up',
  //       title: 'Sign Up',
  //       to: '/sign-up'
  //     },
  //     {
  //       eventKey: 'error403',
  //       title: 'Error 403',
  //       to: '/error-403'
  //     },
  //     {
  //       eventKey: 'error404',
  //       title: 'Error 404',
  //       to: '/error-404'
  //     },
  //     {
  //       eventKey: 'error500',
  //       title: 'Error 500',
  //       to: '/error-500'
  //     },
  //     {
  //       eventKey: 'error503',
  //       title: 'Error 503',
  //       to: '/error-503'
  //     }
  //   ]
  // }
];
