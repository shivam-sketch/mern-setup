import { useMutation, useQuery } from '@tanstack/react-query'
import React, { useEffect } from 'react'
import { Button, Modal } from 'react-bootstrap'
import cogoToast from 'cogo-toast'
import { useForm } from 'react-hook-form'
import api from '../../../lib/api'
import { useNavBar } from '../../../hooks/useNavBarContext'

const AddGlobalAnnouncements = ({ show, setShow, refetch }) => {
    const { community } = useNavBar()
    const handleClose = () => {

        setShow(false)

    }



    const {
        register,
        handleSubmit,
        watch,
        reset,
        setValue,
        formState: { errors },
    } = useForm()





    const { mutate } = useMutation({
        mutationFn: (data) => api.post("/web/add-announcements", data),


        onError: (data, error, variables, context) => {
            // An error happened!
            if (data.response.data.message) {

                cogoToast.error(`${data.response.data.message}`);
            } else {
                cogoToast.error(`server error`);

            }


        },
        onSuccess: (data, variables, context) => {
            console.log("variable", variables);
            if (data.data.status == 201) {
                cogoToast.success(`${data?.data?.message}`);
                setTimeout(() => {
                    setShow(false)
                }, 1000)
                refetch()
            }
        },

    });








    const onSubmit = (data) => {
        const body = {
            title: data.title,
            message: data.message,
            dateAndTime: data.dateAndTime,
            announcementType: 'global',
            community


        }


        mutate(body)
    }








    return (
        <Modal show={show} onHide={handleClose}>

            <Modal.Body>
                <main className="content">
                    <div>
                        {/* <a id="btn-toggle" href="#" className="sidebar-toggler break-point-sm">
                            <i className="ri-menu-line ri-xl"></i>
                        </a> */}
                        <div className="container px-44">
                            <div className="row">
                                <div className="col-xl-12">
                                    <div className="card border-0 py-4 px-2">
                                        <h4 className="text-slate mb-3">Add Global Announcements</h4>
                                        <div className="card-body px-0">
                                            <form className="common-form" onSubmit={handleSubmit(onSubmit)} >
                                                <div className="mb-4">
                                                    <label className="form-label">Title</label>
                                                    <input type="text" className="form-control" placeholder="Enter Title" {...register("title", { required: "Title is required" })} />
                                                    {errors.title && <p style={{ color: 'red' }} role="alert">{errors.title.message}</p>}

                                                </div>
                                                <div className="mb-4">
                                                    <label className="form-label">Message</label>
                                                    <input type="text" className="form-control" placeholder="Enter Message" {...register("message", { required: "message is required" })} />
                                                    {errors.message && <p style={{ color: 'red' }} role="alert">{errors.message.message}</p>}

                                                </div>

                                                <div className="mb-4">
                                                    <label className="form-label">Date</label>
                                                    <input type="date" className="form-control"  {...register("dateAndTime")} />
                                                    {errors.dateAndTime && <p style={{ color: 'red' }} role="alert">{errors.dateAndTime.message}</p>}

                                                </div>

                                                <button type="submit" className="btn btn-main Shadow">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </Modal.Body>




        </Modal>
    )
}

export default AddGlobalAnnouncements